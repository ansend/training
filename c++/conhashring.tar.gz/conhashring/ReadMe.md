## Consistent Hash Ring ##
- Weighted [1,10] consistent hash
- BSD licensed with no dependencies (i.e. just drop the source file into your project)

## author ##
	成杰 service组	chengjie@yy.com litbig@sina.com