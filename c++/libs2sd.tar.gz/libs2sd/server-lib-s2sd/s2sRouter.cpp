#include <sys/eventfd.h>
#include "s2sRouter.h"

using namespace core;

IS2SRouter::IS2SRouter()
{

}
IS2SRouter::~IS2SRouter()
{

}

bool IS2SRouter::dispatch(int64_t serverId, std::string& str)
{
	return dispatcher->dispatchByServerId(serverId, str);
}

bool IS2SRouter::dispatch(int64_t serverId, uint32_t uri, const sox::Marshallable &obj)
{
	return _dispatch(serverId, uri, obj);
}

bool IS2SRouter::dispatch(int64_t serverId, uint32_t uri, const std::string& str)
{
	return _dispatch(serverId, uri, str);
}
bool IS2SRouter::dispatch(uint32_t uConnid, uint32_t uri, const sox::Marshallable &obj)
{
	return _dispatch(uConnid, uri, obj);
}
bool IS2SRouter::dispatch(uint32_t uConnid, core::Sender & sdr)
{
	return _dispatch(uConnid, sdr);
}

bool IS2SRouter::dispatch(int64_t serverId, core::Sender& sdr)
{
	return _dispatch(serverId, sdr);
}

bool IS2SRouter::dispatch(const std::string& strIp, uint16_t uPort, uint32_t uUri, sox::Marshallable& obj)
{
	return _dispatch(strIp, uPort, uUri, obj);
}

bool IS2SRouter::dispatch(const std::string& strIp, uint16_t uPort, uint32_t uUri, const std::string& str)
{
	return _dispatch(strIp, uPort, uUri, str);
}

S2SRouter::S2SRouter()
{

}
S2SRouter::~S2SRouter()
{
	
}
std::string S2SRouter::GetFrom()
{
	return tmpFrom;
}
void S2SRouter::SetFrom(const std::string &f)
{
	tmpFrom = f;
}
bool S2SRouter::_dispatch(int64_t serverId, uint32_t uri, const sox::Marshallable &obj)
{
	// µ¥Ïß³ÌÇéÐÎÏÂ£¬Ö±½Ó·¢ËÍ
	core::Sender s(uri, obj);
	return dispatcher->dispatchByServerId(serverId, s);
}

bool S2SRouter::_dispatch(int64_t serverId, uint32_t uri, const std::string& str)
{
	// µ¥Ïß³ÌÇéÐÎÏÂ£¬Ö±½Ó·¢ËÍ
	core::Sender s;
	s.setUri(uri);
	s.marshall(str.data(), str.length());
	return dispatcher->dispatchByServerId(serverId, s);
}

bool S2SRouter::_dispatch(uint32_t uConnid, uint32_t uri, const sox::Marshallable &obj)
{
	// µ¥Ïß³ÌÇéÐÎÏÂ£¬Ö±½Ó·¢ËÍ
	core::Sender s(uri, obj);
	return dispatcher->dispatchByConnid(uConnid, s);
}
bool S2SRouter::_dispatch(uint32_t uConnid, core::Sender& sdr)
{
	return dispatcher->dispatchByConnid(uConnid, sdr);
}

bool S2SRouter::_dispatch(int64_t serverId, core::Sender& sdr)
{
	return dispatcher->dispatchByServerId(serverId, sdr);
}

bool S2SRouter::_dispatch(const std::string& strIp, uint16_t uPort, uint32_t uUri, const std::string& str)
{
	core::Sender s;
	s.setUri(uUri);
	s.marshall(str.data(), str.length());
	return dispatcher->dispatchByIpPort(strIp, uPort, s);
}

bool S2SRouter::_dispatch(const std::string& strIp, uint16_t uPort, uint32_t uUri, sox::Marshallable& obj)
{
	core::Sender s(uUri, obj);
	return dispatcher->dispatchByIpPort(strIp, uPort, s);
}

// ¶àÏß³ÌÅÉ·¢
ThreadRouter::ThreadRouter()
{

}

ThreadRouter::~ThreadRouter()
{

}
std::string ThreadRouter::GetFrom()
{
	return tmpFrom;
}
void ThreadRouter::SetFrom(const std::string &f)
{
	tmpFrom = f;
}

void ThreadRouter::AddToQueue(int64_t serverId, core::Sender* p)
{
	boost::mutex::scoped_lock sl(m_lstLock);
	m_lstPackets.push_back(AsyncPacket(serverId, p));
}

void ThreadRouter::AddToQueue(uint32_t uConnid, core::Sender* p)
{
	boost::mutex::scoped_lock sl(m_connidlstLock);
	m_lstConnidPackets.push_back(AsyncConnidPacket(uConnid, p));
}

void ThreadRouter::AddToQueue(const std::string& strIp, uint16_t uPort, core::Sender* p)
{
	boost::mutex::scoped_lock sl(m_ipPortlstLock);
	m_lstIpPortPackets.push_back(AsyncIpPortPacket(strIp, uPort, p));
}

void ThreadRouter::Flush()
{
	boost::mutex::scoped_lock sl(m_lstLock);
	std::list<AsyncPacket>::iterator it = m_lstPackets.begin();
	while (it != m_lstPackets.end())
	{
		dispatcher->dispatchByServerId(it->serverId, *(it->pkt));
		delete it->pkt;

		it = m_lstPackets.erase(it);
	}
	sl.unlock();

	boost::mutex::scoped_lock lockConnidList(m_connidlstLock);
	std::list<AsyncConnidPacket>::iterator itConnidPacket = m_lstConnidPackets.begin();
	while (itConnidPacket != m_lstConnidPackets.end())
	{
		dispatcher->dispatchByConnid(itConnidPacket->uConnid, *(itConnidPacket->pkt));
		delete itConnidPacket->pkt;

		itConnidPacket = m_lstConnidPackets.erase(itConnidPacket);
	}
	lockConnidList.unlock();

	boost::mutex::scoped_lock lockIpPortList(m_ipPortlstLock);
	std::list<AsyncIpPortPacket>::iterator itIpPortPacket = m_lstIpPortPackets.begin();
	while (itIpPortPacket != m_lstIpPortPackets.end())
	{
		dispatcher->dispatchByIpPort(itIpPortPacket->strIp, itIpPortPacket->port, *(itIpPortPacket->pkt));
		delete itIpPortPacket->pkt;

		itIpPortPacket = m_lstIpPortPackets.erase(itIpPortPacket);
	}
	lockIpPortList.unlock();
}

S2SAsyncRouter::S2SAsyncRouter() :
	m_fd(-1), m_pipeConn(NULL), m_bFlushFlag(false)
{
	m_fd = ::eventfd(0, EFD_NONBLOCK | EFD_CLOEXEC);
	assert(m_fd != -1);

	// Ö÷Ïß³Ì·¢°ü
	m_pipeConn = new s2sPipeConn();
	m_pipeConn->watch(m_fd, this);
	
	// Ã¿100ºÁÃë½«ËùÓÐÏß³ÌµÄ´ý·¢ËÍ°üÈ«²¿Ò»´ÎÐÔ·¢ËÍ
	m_flushTimer.Init(this, &S2SAsyncRouter::__sendAllFromTimer);
	m_flushTimer.Start(100);
}

S2SAsyncRouter::~S2SAsyncRouter()
{
}

int S2SAsyncRouter::flush(core::IConn *ansConn)
{
	// ·ÀÖ¹ÖØ¸´·¢ËÍFlushÇëÇó
	if (!m_bFlushFlag)
	{
		boost::mutex::scoped_lock sl(route_mux);
		uint64_t u = 0x11111111;
		ssize_t n = ::write(m_fd, &u, sizeof(uint64_t));
		if (n != sizeof(u)) {
			S2SDLOG(Error, "write m_fd:%d writes %d bytes instead of %d", m_fd, n, sizeof(u));
			return 0;
		}
		m_bFlushFlag = true;
	}

	return 0;
}

int S2SAsyncRouter::onData(const char *buf, size_t len, core::IConn *pConn, int type)
{
	if ((pConn != NULL) && (m_pipeConn == pConn))
	{
		uint64_t u;
		int ret = ::read(m_fd, &u, sizeof(uint64_t));
		if (ret == sizeof(uint64_t))
		{
			__sendAll();
		}
	}
	else
	{
		S2SDLOG(Fatal, "m_fd:%u m_Conn:%p pConn:%p", m_fd, m_pipeConn, pConn);
	}
	return len;
}

std::string S2SAsyncRouter::GetFrom()
{
	return __getThreadRoute()->GetFrom();
}
void S2SAsyncRouter::SetFrom(const std::string &f)
{
	__getThreadRoute()->SetFrom(f);	
}

bool S2SAsyncRouter::_dispatch(int64_t serverId, uint32_t uri, const sox::Marshallable &obj)
{
	__getThreadRoute()->AddToQueue(serverId, new core::Sender(uri, obj));
	return true;
}

bool S2SAsyncRouter::_dispatch(int64_t serverId, uint32_t uri, const std::string& str)
{
	core::Sender *pS = new core::Sender();
	pS->setUri(uri);
	pS->marshall(str.data(), str.length());
	__getThreadRoute()->AddToQueue(serverId, pS);
	return true;
}

bool S2SAsyncRouter::_dispatch(uint32_t uConnid, uint32_t uri, const sox::Marshallable &obj)
{
	__getThreadRoute()->AddToQueue(uConnid, new core::Sender(uri, obj));
	return true;
}
bool S2SAsyncRouter::_dispatch(uint32_t uConnid, core::Sender& sdr)
{
	__getThreadRoute()->AddToQueue(uConnid, new core::Sender(sdr));
	return true;
}

bool S2SAsyncRouter::_dispatch(int64_t serverId, core::Sender& sdr)
{
	__getThreadRoute()->AddToQueue(serverId, new core::Sender(sdr));
	return true;
}

bool S2SAsyncRouter::_dispatch(const std::string& strIp, uint16_t uPort, uint32_t uUri, const std::string& str)
{
	core::Sender *pS = new core::Sender();
	pS->setUri(uUri);
	pS->marshall(str.data(), str.length());
	__getThreadRoute()->AddToQueue(strIp, uPort, pS);
	return true;
}

bool S2SAsyncRouter::_dispatch(const std::string& strIp, uint16_t uPort, uint32_t uUri, sox::Marshallable& obj)
{
	__getThreadRoute()->AddToQueue(strIp, uPort, new core::Sender(uUri, obj));
	return true;
}

void S2SAsyncRouter::__sendAll()
{
	boost::mutex::scoped_lock sl(route_mux);
	for(std::vector<ThreadRouter*>::iterator it = routes.begin(); it != routes.end(); ++it){
		(*it)->Flush();
	}

	m_bFlushFlag = false;
}

ThreadRouter* S2SAsyncRouter::__getThreadRoute()
{
	if (ptr.get() == NULL)
	{
		boost::mutex::scoped_lock sl(route_mux);
		ThreadRouter *c = new ThreadRouter();
		c->SetS2SDispatcher(dispatcher);
		routes.push_back(c);
		ptr.reset(c);
	}

	return ptr.get();
}

void core::S2SAsyncRouter::__sendAllFromTimer()
{
	//´¥·¢Ö÷Ïß³Ì·¢°ü£¬¶ø²»ÊÇÖ±½ÓÔÚ×ÓÏß³Ì·¢°ü
	flush(NULL);
}
