#pragma once

#include "s2sPublic.h"
#include "server_common/server-lib3/interface.h"

namespace core {

class CS2SLib3Writer: public IWriter
{
	virtual void answer(uint32_t uri, const sox::Marshallable &obj);
	virtual void answerErr(uint32_t uri, uint16_t ResCode){};
	virtual void stop(){};
	virtual int flush(IConn *ansConn = NULL){return 0;};	
};

}