#include "s2sDataHandler.h"

using namespace core;

#define REPORT_TIME_OUT 60 * 1000

CS2SDataHandler::CS2SDataHandler() :
    BackLinkHandler(), m_pCurConn(NULL)
{

}
CS2SDataHandler::~CS2SDataHandler()
{

}

int CS2SDataHandler::doRequest(Request &request, IConn *conn)
{
    int iRet = 0;
    m_uProcCount ++;
    m_pCurConn = conn;

    IWriter *writer = appContext->requestDispatch(request, conn);
    if (writer)
    {
        iRet = writer->flush(conn);
    }

    m_pCurConn = NULL;
    return iRet;
}
void CS2SDataHandler::handle(int sig)
{
    S2SDLOG(Notice, "proc:%u", m_uProcCount);
#ifdef DYNAMIC_LOG
    if (m_uProcCount > 5000)
    {
        LogLevelNoticeSigHandler(1);
    }else if (m_uProcCount>0){
        LogLevelDebugSigHandler(1);
    }
#endif

    m_uProcCount = 0;
    select_timeout(REPORT_TIME_OUT);    
}

core::IConn * CS2SDataHandler::getCurConn()
{
    return m_pCurConn;
}
uint32_t CS2SDataHandler::getCurConnId()
{
    if (NULL != m_pCurConn)    
    {
        return m_pCurConn->getConnId();
    }
    return 0;
}
bool CS2SDataHandler::isOnHandle()
{
    return (NULL != m_pCurConn);  
}