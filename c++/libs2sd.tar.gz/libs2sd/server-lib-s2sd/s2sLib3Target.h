#pragma once

#include <boost/thread/mutex.hpp>
#include <boost/thread/tss.hpp>
#include "s2sPublic.h"
#include "server_common/server-lib3/interface.h"

namespace core {

// 通常用于替换旧daemon的lib3的InstanceTarget
// 一般不直接生成对象，业务继承直接使用接口
// 请初始化时设置wirter和dispatcher, 内部根据上下文回复s2sd或旧daemon
class CS2SLib3Target : public InstanceTarget, public IGroupNameDispatcherAware
{
public:
    void setDaemonPointer(core::SimpleWriter * pW, core::IGroupNameDispatcher * pD);
	void setExtPacker(IWriter* packer); 
		
    // writer API
    void answer(uint32_t uri, uint16_t res);
    void answer(uint32_t uri, uint16_t res, const sox::Marshallable & obj);

    // dispatcher API
    int dispatchByGroupName(const std::string & serverName, int groupId, uint32_t uri, sox::Marshallable & obj);
    int dispatchByServerID(int64_t serverId, uint32_t uri, sox::Marshallable & obj);
	int dispatchToAll(const std::string &name, int groupId, uint32_t uri, sox::Marshallable& obj);

private:
	boost::thread_specific_ptr<IWriter> pExtPacker;
};

}