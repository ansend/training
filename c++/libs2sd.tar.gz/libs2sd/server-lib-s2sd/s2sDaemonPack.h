#pragma once

#include "server_common/protocol/prouter.h"
#include "s2sdEnv.h"

namespace core { namespace s2sd {

// server::router::PRouter
// server::router::PServerIdRouter

inline void packRoute(core::RouterBase & base, uint32_t uri, const sox::Marshallable & obj)
{
    base.from = s2sd::getServer()->getFullName();
    base.ttl  = 2;
    base.resCode = RES_SUCCESS;
    base.ruri = uri;
    base.packLoad(obj); 
}
inline void packRoute(core::RouterBase & base, uint32_t uri, const std::string & str)
{
    base.from = s2sd::getServer()->getFullName();
    base.ttl  = 2;
    base.resCode = RES_SUCCESS;
    base.ruri = uri;
    base.packLoad(str);     
}

} }
