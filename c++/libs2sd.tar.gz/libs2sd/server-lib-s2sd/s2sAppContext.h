#pragma once

#include "core/corelib/MfcAppContext.h"
#include "server_common/protocol/prouter.h"
#include "s2sPublic.h"

namespace core
{
class CS2SAppContext :
    public core::PHClass,
    public core::MfcAppcontext,
    public Singleton<CS2SAppContext>
{
public:
    DECLARE_FORM_MAP

    CS2SAppContext();
    virtual void addEntry(FormEntry *entries, void *target, IWriterAware *inf);

    void route(server::router::PRouter *rt, IConn *conn);
    void routeS(server::router::PServerIdRouter *rt, IConn *conn);
};
}