#pragma once

#include "s2sPublic.h"
#include "core/corelib/BackLinkHandler.h"

namespace core {

class CS2SDataHandler :
    public BackLinkHandler,
    public Singleton<CS2SDataHandler>
{
public:
    CS2SDataHandler();
    virtual ~CS2SDataHandler();

    virtual int doRequest(Request &request, IConn *rconn);
    virtual void handle(int sig);

    bool isOnHandle();
    core::IConn * getCurConn();
    uint32_t getCurConnId();

private:
    uint32_t m_uProcCount;
    IConn * m_pCurConn;
};

}