#include "StaticHostInfo.h"

using namespace core;
using namespace s2sd;

#define  LOCAL_CONFIG_FILE              "/home/dspeak/yyms/hostinfo.ini"
enum
{
  STATUS = 0,
  DNIPS,
  AREA_ID,
  CITY_ID,
  SEC_GROUP_ID,
  GUID,
  SERVER_ID,
  ROOM,
  IP_ISP_LIST,
  PRI_GROUP_ID,
  IDC_ID,
  DEPT,
  ROOM_ID
};

const char *const item[] =
{
  "status",
  "dnips",
  "area_id",
  "city_id",
  "sec_group_id",
  "guid",
  "server_id",
  "room",
  "ip_isp_list",
  "pri_group_id",
  "idc_id",
  "dept",
  "room_id"
};

StaticHostInfo::StaticHostInfo()
{
  m_status     = 0;
  m_area       = 0;
  m_cityId     = 0;
  m_serverId   = 0;
  m_secGroupId = 0;
  m_priGroupId = 0;
  m_idcId      = 0;
  m_roomId     = 0;
  m_dnips      = "";
  m_gUid       = "";
  m_room       = "";
  m_dept       = "";
  m_isp2Ip.clear();

  if (!load(LOCAL_CONFIG_FILE))
  {
    ::exit(-1);
  }
}

StaticHostInfo::~StaticHostInfo()
{
}

bool StaticHostInfo::load(const char *file)
{
  FILE *fp = fopen(file, "r");
  if (fp == NULL)
  {
    S2SDLOG(Info, "StaticHostInfo::load: Config file %s not existed", file);
    return false;
  }

  long length = 0;
  fseek(fp, 0, SEEK_END);
  length = ftell(fp);
  fseek(fp, 0, SEEK_SET);

  if (length == 0)
  {
    S2SDLOG(Info, "StaticHostInfo::load: Config file %s is empty", file);
    fclose(fp);
    return false;
  }

  char *buf = new char[length+1];
  buf[0] = 0;

  if (fread(buf, length, 1, fp) != 1)
  {
    S2SDLOG(Info, "StaticHostInfo::load: Read config file %s is failed", file);
    fclose(fp);
    delete[] buf;
    return false;
  }
  buf[length] = '\0';

  std::string data;
  data.assign(buf);

  fclose(fp);
  delete[] buf;

  parseData(data);
  return true;
}

void StaticHostInfo::parseData(std::string &data)
{
  for (uint32_t it = STATUS; it <= ROOM_ID; ++it)
  {
    std::string str;
    str.clear();
    str = searchAttribute(data, item[it]);

    switch (it)
    {
      case DNIPS: m_dnips = str; break;
      case GUID:  m_gUid  = str; break;
      case ROOM:  m_room  = str; break;
      case DEPT:  m_dept  = str; break;

      case STATUS:       m_status     = strtoul(str.c_str(), NULL, 0); break;
      case AREA_ID:      m_area       = strtoul(str.c_str(), NULL, 0); break;
      case CITY_ID:      m_cityId     = strtoul(str.c_str(), NULL, 0); break;
      case SEC_GROUP_ID: m_secGroupId = strtoul(str.c_str(), NULL, 0); break;
      case SERVER_ID:    m_serverId   = strtoul(str.c_str(), NULL, 0); break;
      case PRI_GROUP_ID: m_priGroupId = strtoul(str.c_str(), NULL, 0); break;
      case IDC_ID:       m_idcId      = strtoul(str.c_str(), NULL, 0); break;
      case ROOM_ID:      m_roomId     = strtoul(str.c_str(), NULL, 0); break;

      case IP_ISP_LIST:  parseIsp2ip(str); break;

      default: { ; }
    }
  }
}

void StaticHostInfo::parseIsp2ip(std::string &str)
{
  std::string::size_type pos;
  std::map<std::string, ISPType> ispMap;
  ispMap["CTL"]  = CTL;
  ispMap["CNC"]  = CNC;
  ispMap["BGP"]  = BGP;
  ispMap["EDU"]  = EDU;
  ispMap["WBN"]  = WBN;
  ispMap["MOB"]  = MOB;
  ispMap["CNII"] = CNII;
  ispMap["HK"]   = HK;
  ispMap["BRA"]  = BRA;
  ispMap["EU"]	 = (ISPType)512;
  ispMap["NA"]	 = (ISPType)1024;

  pos = str.find_first_of(":");
  while (pos != std::string::npos)
  {
    std::string::size_type next;
    std::string ipStr;
    std::string ispStr;
    ISPType isp_type;

    ipStr = str.substr(0, pos); 

    pos = str.find_first_not_of(" ", pos + 1);
    if (pos == std::string::npos)
      break;

    next = str.find_first_of(",", pos);               // �Զ������ֲ�ͬ�� IP
    if (next != std::string::npos)
      ispStr = str.substr(pos, next - pos);
    else
      ispStr = str.substr(pos);

    if (ispMap.find(ispStr.c_str()) != ispMap.end())
    {
      isp_type = ispMap[ispStr.c_str()];
      m_isp2Ip[isp_type] = inet_addr(ipStr.c_str());
    }

    if (next == std::string::npos)
      break;

    str = str.substr(next + 1);
    pos = str.find_first_of(":");
  }
}

std::string StaticHostInfo::searchAttribute(std::string &data, const char *str)
{
  std::string::size_type pos;
  std::string attr;
  attr.clear();

  pos = data.find(str);
  if (pos != std::string::npos)
  {
    pos = data.find_first_of("=", pos + 1);

    if (pos != std::string::npos)
    {
      std::string::size_type endpos = data.find_first_of("\n", pos + 1);

      if (endpos != std::string::npos)
        attr = data.substr(pos + 1, endpos - pos - 1);
      else
        attr = data.substr(pos + 1);
    }
  }

  return attr;
}

uint32_t StaticHostInfo::getStatus()
{
  return m_status;
}

uint32_t StaticHostInfo::getAera()
{
  return m_area;
}

uint32_t StaticHostInfo::getCityId()
{
  return m_cityId;
}

uint32_t StaticHostInfo::getServerId()
{
  return m_serverId;
}

uint32_t StaticHostInfo::getSecGroupId()
{
  return m_secGroupId;
}

uint32_t StaticHostInfo::getPriGroupId()
{
  return m_priGroupId;
}

uint32_t StaticHostInfo::getIdcId()
{
  return m_idcId;
}

uint32_t StaticHostInfo::getRoomId()
{
  return m_roomId;
}

std::string StaticHostInfo::getDnips()
{
  return m_dnips;
}

std::string StaticHostInfo::getGuid()
{
  return m_gUid;
}

std::string StaticHostInfo::getRoom()
{
  return m_room;
}

std::string StaticHostInfo::getDept()
{
  return m_dept;
}

ISP2IP_map_t StaticHostInfo::getIsp2Ip()
{
  return m_isp2Ip;
}

bool StaticHostInfo::isSmallIsp()
{
  ISP2IP_map_t::const_iterator it = m_isp2Ip.begin();
  for (; it != m_isp2Ip.end(); ++it)
  {
    ISPType isp = it->first;
    if (isp == CNII || isp == EDU || isp == WBN || isp == MOB)
      return true;
  }
  return false;
}

void StaticHostInfo::getIsp(std::set<ISPType>& ispSet)
{
  if(m_isp2Ip.empty())
    return;
  ISP2IP_map_t::iterator it = m_isp2Ip.begin();
  for (; it != m_isp2Ip.end(); ++it)
  {
    ispSet.insert(it->first);
  }
}

bool StaticHostInfo::reLoad()
{
  m_status       = 0;
  m_area         = 0;
  m_cityId       = 0;
  m_serverId     = 0;
  m_secGroupId   = 0;
  m_priGroupId   = 0;
  m_idcId        = 0;
  m_roomId       = 0;
  m_dnips        = "";
  m_gUid         = "";
  m_room         = "";
  m_dept         = "";
  m_isp2Ip.clear();

  return load(LOCAL_CONFIG_FILE);
}

std::string StaticHostInfo::dumpMyInformation()
{
  std::ostringstream os;

  os << "  status    : " << m_status << std::endl;
  os << "  areaId    : " << m_area << std::endl;
  os << "  cityId    : " << m_cityId << std::endl;
  os << "  serverId  : " << m_serverId << std::endl;
  os << "  secGroupId: " << m_secGroupId << std::endl;
  os << "  priGroupId: " << m_priGroupId << std::endl;
  os << "  idcId     : " << m_idcId << std::endl;
  os << "  roomId    : " << m_roomId << std::endl;
  os << "  dnips     : " << m_dnips.c_str() << std::endl;
  os << "  guid      : " << m_gUid.c_str() << std::endl;
  os << "  room      : " << m_room.c_str() << std::endl;
  os << "  dept      : " << m_dept.c_str() << std::endl;

  for (ISP2IP_map_t::iterator it = m_isp2Ip.begin(); it != m_isp2Ip.end(); ++it)
    os << "  isp:" << it->first << " -> ip:" << sox::addr_ntoa(it->second).c_str() << std::endl;

  S2SDLOG(Info, "Console::dumpMyInformation: %s", os.str().c_str());

  return os.str();
}

