#pragma once

#include "s2sPublic.h"
#include "s2sClientIf.h"

namespace core
{
	class IS2SClientWatcher;
	class IS2SClient
	{
	public:
		virtual ~IS2SClient() {}

		virtual void watch(IS2SClientWatcher * w) = 0;

		// ���ݽ���id��ȡ��ϸ��Ϣ
		virtual bool getServer(S2sMeta &info, int64_t srvId) = 0;

		// ��ȡָ�����ֵ����н���
		virtual bool getServers(std::vector<S2sMeta> &infos, const std::string &name) = 0;

		// ��ȡָ�����ֵ����н��̣����޶�����id
		virtual bool getServersByGroup(std::vector<S2sMeta> &infos, const std::string &name, int group) = 0;

        // ע���Լ�����Ȥ�ķ�����(�Է�����ǰ׺��ʶ)
        virtual void addNotifySuffix(const std::string& suffix) = 0;
        virtual void addNotifySuffix(const std::string& suffix, int32_t group) = 0;
        // �ǲ����Ѿ���ע�ķ���
        virtual bool isNotifySuffix(const std::string & suffix) = 0;

        // �����Զ�������
		virtual void addExtKey(const std::string& key, const std::string& value) = 0;
		virtual void addExtKey(const std::string& key, uint32_t value) = 0;

        virtual int setMine(void) = 0;
        virtual void reCreateMetaData(void) = 0;
	};

	class IS2SClientWatcher
	{
	public:
		virtual ~IS2SClientWatcher() {}

		virtual void onServerRemoved(const S2sMeta& info) = 0;
		virtual void onServerAdd(const S2sMeta& info) = 0;

		// ���̵�һ����������ȡȫ����ͼ�� ����
		// ���������ػ������������ͼ��ȱȽϾɵ�ʱ�� Ҳ�ᴥ��
		virtual void onServerRefresh() = 0;
	};

	class IS2SClientAware
	{
	public:
		IS2SClientAware() : client(0) {}
		virtual ~IS2SClientAware() {}

		void setS2SClient(IS2SClient* c)
		{
			client = c;
		}
        
		IS2SClient* getS2SClient()
		{
			return client;
		}

	protected:
		IS2SClient* client;
	};

	class IS2SClientAwareW : public IS2SClientAware,
							 public IS2SClientWatcher
	{
	public:
		virtual void setS2SClient(IS2SClient* c)
		{
			client = c;
			client->watch(this);
		}
	};
  
  class IS2SClientAware2
  {
  public:
    IS2SClientAware2() : s2sClient(0) {}
    virtual ~IS2SClientAware2() {}
  
    void setS2SClient(core::IS2SClient* c)
    {
      s2sClient = c;
    }
        
    core::IS2SClient* getS2SClient()
    {
      return s2sClient;
    }
  
  protected:
    core::IS2SClient* s2sClient;
  };
  
  class IS2SClientAwareW2 : public IS2SClientAware2,
               public core::IS2SClientWatcher
  {
  public:
    virtual void setS2SClient(core::IS2SClient* c)
    {
      s2sClient = c;
      s2sClient->watch(this);
    }
  };

	class IS2SDispatcher
	{
	public:
		virtual ~IS2SDispatcher() {}

		// ��ǲ�������
		virtual bool dispatchByServerId(int64_t serverId, core::Sender &) = 0;
		virtual bool dispatchByServerId(int64_t serverId, std::string& strPacket) = 0;
		virtual bool dispatchByConnid(uint32_t uConnid, core::Sender &objSender) = 0;
		virtual bool dispatchByIpPort(const std::string& strIp, uint16_t uPort, core::Sender &objSender) = 0;
	};

	class IS2SDispatcherAware
	{
	public:
		IS2SDispatcherAware() : dispatcher(0) {}

		void SetS2SDispatcher(IS2SDispatcher* d)
		{
			dispatcher = d;
		}

		IS2SDispatcher* GetS2SDispatcher()
		{
			return dispatcher;
		}

	protected:
		IS2SDispatcher* dispatcher;
	};

}
