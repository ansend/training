#include "s2sSvrInfo.h"

#include <algorithm>

using namespace protocol;
using namespace core::s2sd;
using namespace std;

//#define RANDOM_POS(size) (size == 0 ? 0 : ( rand() % size))
#define RANDOM_POS(size) (rand() % size)

// 插入服务器记录
void core::s2sd::CS2SServersContainer::AddServer(const CS2SServerBase& srv)
{
	//m_mapServers.insert(make_pair(srv.m_serverId, srv));
	m_mapServers.insert(srv);
}


// 删除服务器记录
void core::s2sd::CS2SServersContainer::RemoveServer(const int64_t srvId)
{
	m_mapServers.erase(srvId);
}


// 根据服务器类型名和网络类型，获取服务器ID
void core::s2sd::CS2SServersContainer::GetServersByNameType(const std::string& name, const uint32_t type, std::vector<int64_t>& vecIDs)
{
	const S2SSvrInfoByNetTypeName_t& idx = m_mapServers.get<SvrInfo_NetTypeName>();
	std::pair<S2SSvrInfoByNetTypeName_t::iterator,S2SSvrInfoByNetTypeName_t::iterator> pMach =
		idx.equal_range(boost::make_tuple(type, name));
	if (pMach.first == pMach.second)
	{
		if (!m_bSuppressLog)
			S2SDLOG(Warn, "Name-Type doesn't exist! (Name=%s, Type=%d)", name.c_str(), type);
	}
	while (pMach.first != pMach.second)
	{
		vecIDs.push_back(pMach.first->m_serverId);
		++pMach.first;
	}

	if (!m_bSuppressLog)
		S2SDLOG(Info, "finish. name-type is %s-%u", name.data(), type);
}

//
void core::s2sd::CS2SServersContainer::GetServersByNameTypeEx(const std::string& name
	, const uint32_t type, std::vector<int64_t>& vecIDs)
{
	uint32_t multiLineType = CNC | CTL;

	GetServersByNameType(name, type, vecIDs);
	GetServersByNameType(name, multiLineType, vecIDs); //Will they overlap?
	
	if (!m_bSuppressLog)
		S2SDLOG(Info, "finish. name-type is %s-%u", name.data(), type);
}

void core::s2sd::CS2SServersContainer::GetServersByNameTypeOtherGroup(const std::string& name,
	uint32_t type, uint32_t group, std::vector<int64_t>& vecIDs)
{
	const S2SSvrInfoByNetTypeName_t& idx = m_mapServers.get<SvrInfo_NetTypeName>();
	std::pair<S2SSvrInfoByNetTypeName_t::iterator,S2SSvrInfoByNetTypeName_t::iterator> pMach =
		idx.equal_range(boost::make_tuple(type, name));
	if (pMach.first == pMach.second)
	{
		if (!m_bSuppressLog)
			S2SDLOG(Warn, "Name-Type doesn't exist! (Name=%s, Type=%d)", name.c_str(), type);
	}
	while (pMach.first != pMach.second)
	{
		if (pMach.first->m_groupId != group)
		{
			vecIDs.push_back(pMach.first->m_serverId);
		}
		++pMach.first;
	}

	if (!m_bSuppressLog)
		S2SDLOG(Info, "finish. name-type-group is %s-%u-%u", name.data(), type, group);
}

void CS2SServersContainer::GetServersByNameGroup(const std::string& name, uint32_t group
	, std::vector<int64_t>& vecIDs)
{
	const S2SSvrInfoByGroupName_t& idx = m_mapServers.get<SvrInfo_GroupIdName>();
	std::pair<S2SSvrInfoByGroupName_t::iterator,S2SSvrInfoByGroupName_t::iterator> pMach =
		idx.equal_range(boost::make_tuple(group, name));
	if (pMach.first == pMach.second)
	{
		if (!m_bSuppressLog)
			S2SDLOG(Error, "Name-Group doesn't exist! (Name=%s, Grpup=%d)", name.c_str(), group);
	}
	while (pMach.first != pMach.second)
	{
		vecIDs.push_back(pMach.first->m_serverId);
		++pMach.first;
	}
}


void core::s2sd::CS2SServersContainer::GetServersByNameIP( const std::string& name
	, uint32_t ip, std::vector<int64_t>& vecIDs )
{
	const S2SSvrInfoByIPName_t& idx = m_mapServers.get<SvrInfo_IPName>();
	std::pair<S2SSvrInfoByIPName_t::iterator,S2SSvrInfoByIPName_t::iterator> pMach =
		idx.equal_range(boost::make_tuple(ip, name));
// 	if (pMach.first == pMach.second)
// 	{
// 		S2SDLOG(Error, "Name-IP doesn't exist! (Name=%s, IP=%X(%s))", name.c_str(), ip, sox::addr_ntoa(ip).c_str());
// 	}
	while (pMach.first != pMach.second)
	{
		vecIDs.push_back(pMach.first->m_serverId);
		++pMach.first;
	}

}

// 根据服务器类型获取服务器ID
void core::s2sd::CS2SServersContainer::GetServersByName(const std::string& name, std::vector<int64_t>& vecIDs)
{
	const S2SSvrInfoByName_t& idx = m_mapServers.get<SvrInfo_Name>();
	std::pair<S2SSvrInfoByName_t::iterator,S2SSvrInfoByName_t::iterator> pMach =
		idx.equal_range(name);
// 	if (pMach.first == pMach.second)
// 	{
// 		S2SDLOG(Error, "Name-Group doesn't exist! (Name=%s)", name.c_str());
// 	}
	while (pMach.first != pMach.second)
	{
		vecIDs.push_back(pMach.first->m_serverId);
		++pMach.first;
	}
	//S2SDLOG(Info, "finish. name is %s", name.data());
}

// 清空容器
void core::s2sd::CS2SServersContainer::ClearServer()
{
	m_mapServers.clear();
}

//
CS2SServerBase core::s2sd::CS2SServersContainer::GetServerByID(const int64_t serverID)
{
	ServersMap_T::const_iterator iter = m_mapServers.find(serverID);

	if (iter == m_mapServers.end())
	{
		return CS2SServerBase();
	}
	else
	{
		return *iter;
	}
}

const char* ISPTypeConv(ISPType v)
{
	switch (v)
	{
	case CTL:
		return "CTL";
	case CNC:
		return "CNC";
	case CNII:
		return "CNII";
	case EDU:
		return "EDU";
	case WBN:
		return "WBN";
	case MOB:
		return "MOB";
	default:
		return "?";
	}
}

void DumpEntry(std::string& strOut, const CS2SServerBase& objEntry)
{
	char buf[256];
	std::string strIPs;
	const std::vector<IpType>& vecIPs = objEntry.m_address.ips;
	for(std::vector<IpType>::const_iterator itIP = vecIPs.begin(); itIP != vecIPs.end(); ++itIP)
	{
		strIPs+= ISPTypeConv(itIP->type);
		strIPs+= "IP:";
		strIPs+= sox::addr_ntoa(itIP->ip);
		strIPs+= " ";
	}

	//dip = sox::addr_ntoa(objEntry.m_address.)
	snprintf(buf, sizeof(buf), "Name:%s SvrID:%ju Net:%u GroupID:%u %sPort:%u\n",
		objEntry.m_sstr.c_str(),objEntry.m_serverId, objEntry.m_netType, objEntry.m_groupId, strIPs.c_str(), objEntry.m_address.port);
	strOut += buf;
}

std::string core::s2sd::CS2SServersContainer::DumpAll( const std::string& name )
{
	std::string strOut;

	if (name.empty())
	{
		ServersMap_T::const_iterator it = m_mapServers.begin();
		for (; it!= m_mapServers.end(); ++it)
		{
			DumpEntry(strOut, *it);
		}
	}
	else
	{
		const S2SSvrInfoByName_t& idx = m_mapServers.get<SvrInfo_Name>();
		std::pair<S2SSvrInfoByName_t::iterator,S2SSvrInfoByName_t::iterator> pMach =
			idx.equal_range(name);
		while (pMach.first != pMach.second)
		{
			DumpEntry(strOut, *pMach.first);
			++pMach.first;
		}
	}

	return strOut;
}

bool core::s2sd::CS2SServersContainer::SuppressLog(bool bFlag /*= true*/)
{
	bool bOrig = m_bSuppressLog;
	m_bSuppressLog = bFlag;
	return bOrig;
}

//
//
//    CS2SServersInfo 实现
//
//

// 通过服务器类型名和网络类型，获取相同网络下同一类型的所有服务器ID
vector<int64_t> core::s2sd::CS2SServersInfo::GetServersIDByNameType(const std::string& name, const uint32_t type)
{
	vector<int64_t> vecIds;
	m_srvContainer.GetServersByNameType(name, type, vecIds);

	return vecIds;
}

vector<int64_t> core::s2sd::CS2SServersInfo::GetServersIDByNameTypeEx(const std::string& name, const uint32_t type)
{
	vector<int64_t> vecIds;
	m_srvContainer.GetServersByNameTypeEx(name, type, vecIds);

	return vecIds;
}

// 通过服务器类型名，获取一类型的所有服务器ID
vector<int64_t> core::s2sd::CS2SServersInfo::GetServersIDByName(const std::string& name)
{
	vector<int64_t> vecIds;
	m_srvContainer.GetServersByName(name, vecIds);

	return vecIds;
}

// 通过服务器名和网络类型，随即获取一个服务器ID
int64_t core::s2sd::CS2SServersInfo::RandomServerIDByNameType(const std::string& name, const uint32_t type)
{
	vector<int64_t> vecIds;
	m_srvContainer.GetServersByNameType(name, type, vecIds);
	size_t uSize = vecIds.size();
	if (uSize)
	{
		//random_shuffle(vecIds.begin(), vecIds.end());
		//return vecIds.front();
		return vecIds[RANDOM_POS(uSize)];
	}
	else
	{
		S2SDLOG(Warn, "no server found. name(%s)-ISP(%d)", name.data(), type);
	}
	return NONE_SERVER_ID64;
}

int64_t core::s2sd::CS2SServersInfo::RandomServerIDByNameTypeEx(const std::string& name, const uint32_t type)
{
	vector<int64_t> vecIds;
	m_srvContainer.GetServersByNameTypeEx(name, type, vecIds);
	size_t uSize = vecIds.size();
	if (uSize)
	{
		return vecIds[RANDOM_POS(uSize)];
	}
	else
	{
		S2SDLOG(Error, "no server found. name(%s)-ISP(%d)", name.data(), type);
	}
	return NONE_SERVER_ID64;
}

int64_t core::s2sd::CS2SServersInfo::RandomServerIDByNameTypeOtherGroup(const std::string& name, uint32_t type, uint32_t group)
{
	vector<int64_t> vecIds;
	m_srvContainer.GetServersByNameTypeOtherGroup(name, type, group, vecIds);
	size_t uSize = vecIds.size();
	if (uSize)
	{
		return vecIds[RANDOM_POS(uSize)];
	}
	else
	{
		S2SDLOG(Warn, "no server found. name(%s)-ISP(%d)-group(%d)", name.data(), type, group);
	}
	return NONE_SERVER_ID64;
}

// 通过服务器名，随即获取一个服务器ID
int64_t core::s2sd::CS2SServersInfo::RandomServerIDByName(const std::string& name)
{
	vector<int64_t> vecIds;
	m_srvContainer.GetServersByName(name, vecIds);
	size_t uSize = vecIds.size();
	if (uSize)
	{
		return vecIds[RANDOM_POS(uSize)];
	}
	else
	{
		S2SDLOG(Error, "no server found. name(%s)", name.data());
	}
	return NONE_SERVER_ID64;
}

// 获取网络类型
uint32_t core::s2sd::CS2SServersInfo::GetNetTypeByID(const int64_t serverID)
{
	 CS2SServerBase tmp = m_srvContainer.GetServerByID(serverID);

	 if (tmp.m_netType == (uint32_t)-1)
	 {
		 S2SDLOG(Error, "server: %ju not found.", serverID);
	 }
	 else
	 {
		 //S2SDLOG(Debug, "server: %u type is %u", serverID, tmp.m_netType);
		 return tmp.m_netType;
	 }
	 return -1;
}
bool core::s2sd::CS2SServersInfo::IsServerIDExist(const int64_t uServerId)
{
	CS2SServerBase tmp = m_srvContainer.GetServerByID(uServerId);
	if (NONE_SERVER_ID64 != tmp.m_serverId)
	{
		return true;
	}
	return false;
}

uint32_t core::s2sd::CS2SServersInfo::GetMyNetType()
{
	return m_uMyNetType;
}

uint32_t core::s2sd::CS2SServersInfo::GetMyMainIp()
{
  return m_uMyMainIP;
}

// 获取groupid
uint32_t core::s2sd::CS2SServersInfo::GetGroupIdBySid(const int64_t serverID)
{
	 CS2SServerBase tmp = m_srvContainer.GetServerByID(serverID);
	 return tmp.m_groupId;
}

// 判断两个服务器是否相同网络类型
bool core::s2sd::CS2SServersInfo::IsSameNetType(const int64_t srvId1, const int64_t srvId2)
{
	CS2SServerBase tmp1 = m_srvContainer.GetServerByID(srvId1);
	CS2SServerBase tmp2 = m_srvContainer.GetServerByID(srvId2);

	return (tmp1.m_netType == tmp2.m_netType);
}

std::vector<int64_t> core::s2sd::CS2SServersInfo::GetServersByNameGroup(const std::string& name, uint32_t group)
{
    std::vector<int64_t> vecIds;
    m_srvContainer.GetServersByNameGroup(name, group, vecIds);
    return vecIds;
}

int64_t core::s2sd::CS2SServersInfo::RandomServerIDByNameGroup(const std::string& name, uint32_t group)
{
	std::vector<int64_t> vecIds = CS2SServersInfo::GetServersByNameGroup(name, group);
	size_t uSize = vecIds.size();

	if (uSize)
	{
		return vecIds[RANDOM_POS(uSize)];
    }
	else
	{
		return NONE_SERVER_ID64;
	}
}

int64_t core::s2sd::CS2SServersInfo::RandomServerIDByNameIP( const std::string& name, uint32_t ip /*= 0*/ )
{
	uint32_t uIP = (0 == ip)?m_uMyMainIP:ip;
	vector<int64_t> vecIds;
	m_srvContainer.GetServersByNameIP(name, uIP, vecIds);
	size_t uSize = vecIds.size();
	if (uSize)
	{
		return vecIds[RANDOM_POS(uSize)];
	}
	else
	{
		//S2SDLOG(Error, "no server found. name(%s)", name.data());
	}
	return NONE_SERVER_ID64;
}

void core::s2sd::CS2SServersInfo::SetMyServerID( const int64_t uServerID )
{
	m_uMyServerId = uServerID;
	S2SDLOG(Info, "done (ServerId=%ju)", uServerID);
}

// void core::s2sd::CS2SServersInfo::AddCareName( const std::string& strName )
// {
// 	m_setCareNames.insert(strName);
// }

void core::s2sd::CS2SServersInfo::onServerRemoved( const S2sMeta& info )
{
	S2sDataDecoder data(info.data);
	std::map<S2S::ISPType, uint32_t> ips;
	data.readIpList(ips);

	m_srvContainer.RemoveServer(info.serverId);
	S2SDLOG(Info, "delete server ok. name(%s)-ips(%s)-srvID(%ju)",
		info.name.data(), dumpIps(ips).c_str(), info.serverId);
}

void core::s2sd::CS2SServersInfo::onServerAdd( const S2sMeta& info )
{
	S2sDataDecoder data(info.data);
	std::map<S2S::ISPType, uint32_t> ips;
	data.readIpList(ips);

	uint32_t uMainIp = 0;

	for(std::map<S2S::ISPType, uint32_t>::const_iterator it = ips.begin();
		it != ips.end(); ++it)
	{
		uMainIp = it->second;
		break;
	}

	uint32_t type = CS2SServerFunc::GetNetType(ips);

	if (type == (uint32_t)-1)
	{
		S2SDLOG(Error, "faild to match server-type, name(%s)-ips(%s)-srvID(%ju)",
			info.name.data(), dumpIps(ips).c_str(), info.serverId);
		return;
	}

	uint32_t port;
	data.readTcpPort(port);

	IpPortInfoCmp pp = constructInfo(ips, port);
	m_srvContainer.AddServer(CS2SServerBase(info.name, info.serverId, type, info.groupId, uMainIp, pp));
	S2SDLOG(Info, "ok. name:%s ips:%s srvID:%ju IP:%X/%s:%u Group:%d type:%u",
		info.name.data(), dumpIps(ips).c_str(), info.serverId, uMainIp, sox::addr_ntoa(uMainIp).c_str(), port, info.groupId, type);
}

void core::s2sd::CS2SServersInfo::onServerRefresh()
{
	//为了支持选择同ip进程，需要通过自己的server id关联ip
	//请确保你的CS2SServersInfo实例调用了SetS2SServer
	if (server) {
		SetMyServerID(server->getServerId());
		std::map<S2S::ISPType, uint32_t> ips = server->getIps();

		for(std::map<S2S::ISPType, uint32_t>::const_iterator it = ips.begin();
			it != ips.end(); ++it)
		{
			m_uMyMainIP = it->second;
			break;
		}

		m_uMyNetType = CS2SServerFunc::GetNetType(ips);
		S2SDLOG(Info, "My serverID is %ju. Add my IP %X/%s. My net type is %u",
			m_uMyServerId, m_uMyMainIP,	sox::addr_ntoa(m_uMyMainIP).c_str(), m_uMyNetType);
	}

	m_srvContainer.ClearServer();

	std::vector<S2sMeta> vecSrvInfo;
	getS2SClient()->getServersByGroup(vecSrvInfo, "", 0);

	for(std::vector<S2sMeta>::iterator iter = vecSrvInfo.begin(); iter != vecSrvInfo.end(); ++iter)
	{
		CS2SServersInfo::onServerAdd(*iter);
	}

	S2SDLOG(Info, "finish");
}

std::string core::s2sd::CS2SServersInfo::DumpAll( const std::string& name )
{
	std::string strOut;
	std::vector<S2sMeta> vecInfos;
	client->getServers(vecInfos, name);
	char buf[256];

	snprintf(buf, sizeof(buf), "My ServerID: %ju\nData in MetaServer:\n", m_uMyServerId);
	strOut += buf;

	std::vector<S2sMeta>::const_iterator it = vecInfos.begin();
	for (;it != vecInfos.end(); ++it)
	{
		S2sDataDecoder data(it->data);
		std::map<S2S::ISPType, uint32_t> ips;
		data.readIpList(ips);

		string dip;
		string wip;

		std::map<S2S::ISPType, uint32_t>::iterator itIp = ips.find(S2S::CTL);
		if (itIp != ips.end())
		{
			dip = sox::addr_ntoa(itIp->second);
		}

		itIp = ips.find(S2S::CNC);
		if (itIp != ips.end())
		{
			wip = sox::addr_ntoa(itIp->second);
		}

		uint32_t port;
		data.readTcpPort(port);

		snprintf(buf, sizeof(buf), "name:%s, serverId:%ju, groupId:%d, dip:%s, wip:%s, port:%u, status:%u\n",
			it->name.c_str(),
			it->serverId,
			it->groupId,
			dip.c_str(),
			wip.c_str(),
			port,
			it->status );
		strOut += buf;
	}

	strOut += "\nData in CS2SServersContainer:\n";

	strOut += m_srvContainer.DumpAll(name);
	return strOut;
}

bool core::s2sd::CS2SServersInfo::SuppressContainerLog(bool bFlag /*= true*/)
{
	return m_srvContainer.SuppressLog(bFlag);
}


//
//
//    CS2SServersInfoMT 实现
//
//

// 通过服务器类型名和网络类型，获取相同网络下同一类型的所有服务器ID
vector<int64_t> core::s2sd::CS2SServersInfoMT::GetServersIDByNameType(const std::string& name, const uint32_t type)
{
	vector<int64_t> vecIds;
	CWritePerf_RWLock scopeLock(&m_mutexRWLock);
	m_srvContainer.GetServersByNameType(name, type, vecIds);

	return vecIds;
}

vector<int64_t> core::s2sd::CS2SServersInfoMT::GetServersIDByNameTypeEx(const std::string& name, const uint32_t type)
{
	vector<int64_t> vecIds;
	CWritePerf_RWLock scopeLock(&m_mutexRWLock);
	m_srvContainer.GetServersByNameTypeEx(name, type, vecIds);

	return vecIds;
}

// 通过服务器类型名，获取一类型的所有服务器ID
vector<int64_t> core::s2sd::CS2SServersInfoMT::GetServersIDByName(const std::string& name)
{
	vector<int64_t> vecIds;
	CWritePerf_RWLock scopeLock(&m_mutexRWLock);
	m_srvContainer.GetServersByName(name, vecIds);

	return vecIds;
}

// 通过服务器名和网络类型，随即获取一个服务器ID
int64_t core::s2sd::CS2SServersInfoMT::RandomServerIDByNameType(const std::string& name, const uint32_t type)
{
	vector<int64_t> vecIds;
	CWritePerf_RWLock scopeLock(&m_mutexRWLock);
	m_srvContainer.GetServersByNameType(name, type, vecIds);
	size_t uSize = vecIds.size();
	if (uSize)
	{
		//random_shuffle(vecIds.begin(), vecIds.end());
		//return vecIds.front();
		return vecIds[RANDOM_POS(uSize)];
	}
	else
	{
		S2SDLOG(Warn, "no server found. name(%s)-ISP(%d)", name.data(), type);
	}
	return NONE_SERVER_ID64;
}

int64_t core::s2sd::CS2SServersInfoMT::RandomServerIDByNameTypeEx(const std::string& name, const uint32_t type)
{
	vector<int64_t> vecIds;
	CWritePerf_RWLock scopeLock(&m_mutexRWLock);
	m_srvContainer.GetServersByNameTypeEx(name, type, vecIds);
	size_t uSize = vecIds.size();
	if (uSize)
	{
		return vecIds[RANDOM_POS(uSize)];
	}
	else
	{
		S2SDLOG(Error, "no server found. name(%s)-ISP(%d)", name.data(), type);
	}
	return NONE_SERVER_ID64;
}

int64_t core::s2sd::CS2SServersInfoMT::RandomServerIDByNameTypeOtherGroup(const std::string& name, uint32_t type, uint32_t group)
{
	vector<int64_t> vecIds;
	CWritePerf_RWLock scopeLock(&m_mutexRWLock);
	m_srvContainer.GetServersByNameTypeOtherGroup(name, type, group, vecIds);
	size_t uSize = vecIds.size();
	if (uSize)
	{
		return vecIds[RANDOM_POS(uSize)];
	}
	else
	{
		S2SDLOG(Warn, "no server found. name(%s)-ISP(%d)-group(%d)", name.data(), type, group);
	}
	return NONE_SERVER_ID64;
}

// 通过服务器名，随即获取一个服务器ID
int64_t core::s2sd::CS2SServersInfoMT::RandomServerIDByName(const std::string& name)
{
	vector<int64_t> vecIds;
	CWritePerf_RWLock scopeLock(&m_mutexRWLock);
	m_srvContainer.GetServersByName(name, vecIds);
	size_t uSize = vecIds.size();
	if (uSize)
	{
		return vecIds[RANDOM_POS(uSize)];
	}
	else
	{
		S2SDLOG(Error, "no server found. name(%s)", name.data());
	}
	return NONE_SERVER_ID64;
}

// 获取网络类型
uint32_t core::s2sd::CS2SServersInfoMT::GetNetTypeByID(const int64_t serverID)
{
	CWritePerf_RWLock scopeLock(&m_mutexRWLock);
	 CS2SServerBase tmp = m_srvContainer.GetServerByID(serverID);

	 if (tmp.m_netType == (uint32_t)-1)
	 {
		 S2SDLOG(Error, "server: %ju not found.", serverID);
	 }
	 else
	 {
		 //S2SDLOG(Debug, "server: %u type is %u", serverID, tmp.m_netType);
		 return tmp.m_netType;
	 }
	 return -1;
}
bool core::s2sd::CS2SServersInfoMT::IsServerIDExist(const int64_t uServerId)
{
	CWritePerf_RWLock scopeLock(&m_mutexRWLock);
	CS2SServerBase tmp = m_srvContainer.GetServerByID(uServerId);
	if (NONE_SERVER_ID64 != tmp.m_serverId)
	{
		return true;
	}
	return false;
}

uint32_t core::s2sd::CS2SServersInfoMT::GetMyNetType()
{
	return m_uMyNetType;
}

uint32_t core::s2sd::CS2SServersInfoMT::GetMyMainIp()
{
  return m_uMyMainIP;
}

// 获取groupid
uint32_t core::s2sd::CS2SServersInfoMT::GetGroupIdBySid(const int64_t serverID)
{
	CWritePerf_RWLock scopeLock(&m_mutexRWLock);
	 CS2SServerBase tmp = m_srvContainer.GetServerByID(serverID);
	 return tmp.m_groupId;
}

// 判断两个服务器是否相同网络类型
bool core::s2sd::CS2SServersInfoMT::IsSameNetType(const int64_t srvId1, const int64_t srvId2)
{
	CWritePerf_RWLock scopeLock(&m_mutexRWLock);
	CS2SServerBase tmp1 = m_srvContainer.GetServerByID(srvId1);
	CS2SServerBase tmp2 = m_srvContainer.GetServerByID(srvId2);

	return (tmp1.m_netType == tmp2.m_netType);
}

std::vector<int64_t> core::s2sd::CS2SServersInfoMT::GetServersByNameGroup(const std::string& name, uint32_t group)
{
    std::vector<int64_t> vecIds;
    CWritePerf_RWLock scopeLock(&m_mutexRWLock);
    m_srvContainer.GetServersByNameGroup(name, group, vecIds);
    return vecIds;
}

int64_t core::s2sd::CS2SServersInfoMT::RandomServerIDByNameGroup(const std::string& name, uint32_t group)
{
	std::vector<int64_t> vecIds = CS2SServersInfoMT::GetServersByNameGroup(name, group);
	size_t uSize = vecIds.size();

	if (uSize)
	{
		return vecIds[RANDOM_POS(uSize)];
    }
	else
	{
		return NONE_SERVER_ID64;
	}
}

int64_t core::s2sd::CS2SServersInfoMT::RandomServerIDByNameIP( const std::string& name, uint32_t ip /*= 0*/ )
{
	uint32_t uIP = (0 == ip)?m_uMyMainIP:ip;
	vector<int64_t> vecIds;
	CWritePerf_RWLock scopeLock(&m_mutexRWLock);
	m_srvContainer.GetServersByNameIP(name, uIP, vecIds);
	size_t uSize = vecIds.size();
	if (uSize)
	{
		return vecIds[RANDOM_POS(uSize)];
	}
	else
	{
		//S2SDLOG(Error, "no server found. name(%s)", name.data());
	}
	return NONE_SERVER_ID64;
}

void core::s2sd::CS2SServersInfoMT::SetMyServerID( const int64_t uServerID )
{
	m_uMyServerId = uServerID;
	S2SDLOG(Info, "done (ServerId=%ju)", uServerID);
}

void core::s2sd::CS2SServersInfoMT::onServerRemoved( const S2sMeta& info )
{
	S2sDataDecoder data(info.data);
	std::map<S2S::ISPType, uint32_t> ips;
	data.readIpList(ips);

	{
		CWritePerf_RWLock scopeLock(&m_mutexRWLock, true);
		m_srvContainer.RemoveServer(info.serverId);
	}
	S2SDLOG(Info, "delete server ok. name(%s)-ips(%s)-srvID(%ju)",
		info.name.data(), dumpIps(ips).c_str(), info.serverId);
}

void core::s2sd::CS2SServersInfoMT::onServerAdd( const S2sMeta& info )
{
	S2sDataDecoder data(info.data);
	std::map<S2S::ISPType, uint32_t> ips;
	data.readIpList(ips);

	uint32_t uMainIp = 0;

	for(std::map<S2S::ISPType, uint32_t>::const_iterator it = ips.begin();
		it != ips.end(); ++it)
	{
		uMainIp = it->second;
		break;
	}

	uint32_t type = CS2SServerFunc::GetNetType(ips);

	if (type == (uint32_t)-1)
	{
		S2SDLOG(Error, "faild to match server-type, name(%s)-ips(%s)-srvID(%ju)",
			info.name.data(), dumpIps(ips).c_str(), info.serverId);
		return;
	}

	uint32_t port;
	data.readTcpPort(port);

	IpPortInfoCmp pp = constructInfo(ips, port);
	{
		CWritePerf_RWLock scopeLock(&m_mutexRWLock, true);
		m_srvContainer.AddServer(CS2SServerBase(info.name, info.serverId, type, info.groupId, uMainIp, pp));
	}
	S2SDLOG(Info, "ok. name:%s ips:%s srvID:%ju IP:%X/%s Group:%d type:%u",
		info.name.data(), dumpIps(ips).c_str(), info.serverId, uMainIp, sox::addr_ntoa(uMainIp).c_str(), info.groupId, type);

}

void core::s2sd::CS2SServersInfoMT::onServerRefresh()
{
	//为了支持选择同ip进程，需要通过自己的server id关联ip
	//请确保你的CS2SServersInfo实例调用了SetS2SServer
	if (server) {
		SetMyServerID(server->getServerId());
		std::map<S2S::ISPType, uint32_t> ips = server->getIps();

		for(std::map<S2S::ISPType, uint32_t>::const_iterator it = ips.begin();
			it != ips.end(); ++it)
		{
			m_uMyMainIP = it->second;
			break;
		}

		m_uMyNetType = CS2SServerFunc::GetNetType(ips);
		S2SDLOG(Info, "My serverID is %ju. Add my IP %X/%s. My net type is %u",
			m_uMyServerId, m_uMyMainIP,	sox::addr_ntoa(m_uMyMainIP).c_str(), m_uMyNetType);
	}

	{
		CWritePerf_RWLock scopeLock(&m_mutexRWLock, true);
		m_srvContainer.ClearServer();
	}

	std::vector<S2sMeta> vecSrvInfo;
	getS2SClient()->getServersByGroup(vecSrvInfo, "", 0);

	for(std::vector<S2sMeta>::iterator iter = vecSrvInfo.begin(); iter != vecSrvInfo.end(); ++iter)
	{
		CS2SServersInfoMT::onServerAdd(*iter);
	}

	S2SDLOG(Info, "finish");
}

std::string core::s2sd::CS2SServersInfoMT::DumpAll( const std::string& name )
{
	std::string strOut;
	std::vector<S2sMeta> vecInfos;
	client->getServers(vecInfos, name);
	char buf[256];

	snprintf(buf, sizeof(buf), "My ServerID: %ju\nData in MetaServer:\n", m_uMyServerId);
	strOut += buf;

	std::vector<S2sMeta>::const_iterator it = vecInfos.begin();
	for (;it != vecInfos.end(); ++it)
	{
		S2sDataDecoder data(it->data);
		std::map<S2S::ISPType, uint32_t> ips;
		data.readIpList(ips);

		string dip;
		string wip;

		std::map<S2S::ISPType, uint32_t>::iterator itIp = ips.find(S2S::CTL);
		if (itIp != ips.end())
		{
			dip = sox::addr_ntoa(itIp->second);
		}

		itIp = ips.find(S2S::CNC);
		if (itIp != ips.end())
		{
			wip = sox::addr_ntoa(itIp->second);
		}

		uint32_t port;
		data.readTcpPort(port);

		snprintf(buf, sizeof(buf), "name:%s, serverId:%ju, groupId:%d, dip:%s, wip:%s, port:%u, status:%u\n",
			it->name.c_str(),
			it->serverId,
			it->groupId,
			dip.c_str(),
			wip.c_str(),
			port,
			it->status );
		strOut += buf;
	}

	strOut += "\nData in CS2SServersContainer:\n";

	CWritePerf_RWLock scopeLock(&m_mutexRWLock);
	strOut += m_srvContainer.DumpAll(name);
	return strOut;
}

bool core::s2sd::CS2SServersInfoMT::SuppressContainerLog(bool bFlag /*= true*/)
{
	return m_srvContainer.SuppressLog(bFlag);
}
