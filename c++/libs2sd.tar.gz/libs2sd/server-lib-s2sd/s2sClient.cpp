
#include "s2sClient.h"
#include "s2sSvrInfo.h"
#include <typeinfo>

using namespace std;
using namespace core;

CS2SClient::CS2SClient()
: m_s2sfd(-1), m_pipeConn(NULL), m_pMetaServer(0),
	m_isStarted(false),m_isBind(false),m_hasRefreshed(false)
{
	m_pMetaData = new S2sDataEncoder();	
	m_pMetaServer = newMetaServer();
}

CS2SClient::~CS2SClient()
{
	if(m_pMetaData != NULL)
	{
		delete m_pMetaData;
	}
	if (NULL != m_pipeConn)
	{
		delete m_pipeConn;
	}
}

bool CS2SClient::watchFd(int watchFd)
{
	m_pipeConn = new s2sPipeConn();
	if (!m_pipeConn->watch(watchFd, this))
	{
	  S2SDLOG(Fatal, "Watch pipeConn %d failed", watchFd);
	  ::exit(-1);
	}

	return true;
}
int CS2SClient::onData(const char *buf, size_t len, core::IConn *pConn, int type)
{
	if ((pConn != NULL) && (m_pipeConn == pConn))
	{
		std::vector<S2sMeta> updateMetas;
		S2sSessionStatus rc = m_pMetaServer->pollNotify(updateMetas);
		S2SDLOG(Info, "S2sSessionStatus: %u, updateMeta size = %u",rc, updateMetas.size());

		// handle status
		handleS2sSessionStatus(rc);

		if(!updateMetas.empty())
		{
			// handle updateMetas
			handleUpdateMetas(updateMetas);
		}
	}

	return len;	
}

void CS2SClient::handleS2sSessionStatus(S2sSessionStatus status)
{
	switch(status)
	{
	case S2S_SESSIONBIND_C:
		if(!m_isBind)
		{
			// 更新进程id
			S2sMeta info;
			if (m_pMetaServer->getMine(info) != 0)
			{
				S2SDLOG(Error, "IMetaServer::getMine failed!");
				return;
			}
			S2SDLOG(Info, "server id:%ju", info.serverId);
			server->setServerId(info.serverId);	

			m_isBind = true;

			if(!m_hasRefreshed)
			{
				S2SDLOG(Info, "onRefresh to Servers, m_sid2Metas size = %u wathcers:%u", m_sid2Metas.size(), m_setWatchers.size());
				for (std::set<IS2SClientWatcher *>::iterator it = m_setWatchers.begin(); it != m_setWatchers.end(); ++it)
				{
					(*it)->onServerRefresh();
				}
				
				m_hasRefreshed = true;
			}			
		}
		break;
		
	case S2S_AUTHFAILURE_C:
		S2SDLOG(Error, "S2S_AUTHFAILURE_C");
		::exit(1);
		break;
		
	case S2S_DNSERROR_C:
	case S2S_ERROR_C:
		S2SDLOG(Error, "wrong status: %u", status);
		break;

	default:
		S2SDLOG(Warn, "invalid status: %u", status);
		break;	
	}
}


void CS2SClient::handleUpdateMetas(std::vector<S2sMeta> updateMetas)
{
	for(size_t i = 0; i<updateMetas.size(); ++i)
	{
		S2sMeta & m = updateMetas[i];
		switch (m.status)
		{
		case S2SMETA_OK_C:
			S2SDLOG(Info, "add server id:%ju watchers:%u", m.serverId, m_setWatchers.size());
			if(m_hasRefreshed)
			{
				for (std::set<IS2SClientWatcher *>::iterator itWatchers = m_setWatchers.begin();
						itWatchers != m_setWatchers.end(); ++itWatchers)
				{
					(*itWatchers)->onServerAdd(m);
				}
			}
			m_sid2Metas[m.serverId] = m;
			break;

		case S2SMETA_DIED_C:
			S2SDLOG(Info, "remove server id:%ju watchers:%u", m.serverId, m_setWatchers.size());
			for (std::set<IS2SClientWatcher *>::iterator itWatchers = m_setWatchers.begin();
					itWatchers != m_setWatchers.end(); ++itWatchers)
			{
				(*itWatchers)->onServerRemoved(m);
			}
			m_sid2Metas.erase(m.serverId);
			break;

		default:
            S2SDLOG(Info, "status:%u id:%ju",m.status, m.serverId);
			break;
		}	
	}	
}

void CS2SClient::addNotifySuffix(const std::string& suffix)
{
	addNotifySuffix(suffix, 0);
}

void CS2SClient::addNotifySuffix(const std::string& suffix, int32_t group)
{
	SubFilter f;
	f.interestedName = suffix;
	f.interestedGroup = group;
	f.s2sType = ANY_TYPE;

	m_sunFilters.push_back(f);

	std::size_t size = suffix.size();
	if (suffix[size-1] != '\%')
	{
		m_setSubFilter.insert(suffix);
	}
	else
	{
		m_setSubPattern.insert(suffix);		
	}

	if (m_isStarted)
	{
		std::vector<SubFilter> vecFilters;
		vecFilters.push_back(f);
		int iRet = m_pMetaServer->subscribe(vecFilters);
		S2SDLOG(Notice, "subscribe suffix:%s ret:%d", suffix.c_str(), iRet);
	}
}
bool CS2SClient::isNotifySuffix(const std::string & suffix)
{
	if (0 != m_setSubFilter.count(suffix))
	{
		return true;
	}
	std::set<std::string>::iterator sIt = m_setSubPattern.begin();
	for (; sIt != m_setSubPattern.begin(); ++sIt)
	{
		const std::string strPattern = *sIt;
		const std::size_t uPattern = strPattern.size() - 1;
		if (0 == suffix.compare(0, uPattern, strPattern, 0, uPattern))
		{
			return true;
		}
	}

	return false;	
}

void CS2SClient::addExtKey(const std::string& key, const std::string& value)
{
	m_pMetaData->insert(key, value);
}

void CS2SClient::addExtKey(const std::string& key, uint32_t value)
{
	m_pMetaData->insert(key, value);
}

void CS2SClient::reCreateMetaData(void)
{
	if(m_pMetaData != NULL)
	{
		delete m_pMetaData;
	}

	//re-create meta data,since not support updation or deletion.
	m_pMetaData = new S2sDataEncoder();

	//set my ip port inform.
	std::map<S2S::ISPType, uint32_t> ips = server->getIps();

	m_pMetaData->writeIpList(ips);
	m_pMetaData->writeTcpPort(server->getPort());	
}

int CS2SClient::setMine(void)
{	
	std::string data = m_pMetaData->endToString();
	if(!data.empty())
	{
		return m_pMetaServer->setMine(data);
	}
	S2SDLOG(Warn, "data empty");
	return -1;
}

bool CS2SClient::Start()
{
	// 将自身的IP地址作为data段
	std::map<S2S::ISPType, uint32_t> ips = server->getIps();

	m_pMetaData->writeIpList(ips);
	m_pMetaData->writeTcpPort(server->getPort());

	m_pMetaServer->setGroupId(server->getGroupId());
	if ((m_s2sfd = m_pMetaServer->initialize(server->getName(),server->getS2sKey(),S2SDECODER) ) <= 0)
	{
		S2SDLOG(Error, "initialize meta server failed.");
		::exit(-1);
	}
	
	S2SDLOG(Warn, "m_s2sfd = %d", m_s2sfd);
	// sub
	if(!m_sunFilters.empty())
	{
		if(m_pMetaServer->subscribe(m_sunFilters) == -1)
		{
			S2SDLOG(Error, "subscribe failed.");
			return false;			
		}
	}

	// reg
	std::string data = m_pMetaData->endToString();
	if(!data.empty())
	{
		if(m_pMetaServer->setMine(data) == -1)
		{
			S2SDLOG(Error, "setMine failed.");
			return false;
		}
	}

	watchFd(m_s2sfd);
	m_isStarted = true;
	return true;
}


bool CS2SClient::Stop()
{
	return (m_pMetaServer->delMine() == 0);
}


void CS2SClient::watch(IS2SClientWatcher * w)
{
	m_setWatchers.insert(w);
	S2SDLOG(Notice, "add watcher:%p-%s", w, typeid(*w).name());
}

bool CS2SClient::getServer(S2sMeta &info, int64_t srvId)
{
	std::map<int64_t, S2sMeta>::iterator it = m_sid2Metas.find(srvId);
	if(it != m_sid2Metas.end())
	{
		info = it->second;
		return true;
	}
	S2SDLOG(Info, "srvId =%jd", srvId);
	return false;
}

bool CS2SClient::getServers(std::vector<S2sMeta> &infos, const std::string &name)
{
 	std::map<int64_t, S2sMeta>::iterator it = m_sid2Metas.begin();
	for(; it != m_sid2Metas.end(); ++it)
	{
		S2sMeta& tmp = it->second;
		if(tmp.name == name || name.empty())
		{
			infos.push_back(tmp);
		}
	}

	if(name.empty())
	{
		S2SDLOG(Info, "name empty, size = %u", infos.size());
	}
	else
	{
		S2SDLOG(Info, "name =%s, size = %u", name.c_str(), infos.size());
	}
	
	return true;
}

bool CS2SClient::getServersByGroup(std::vector<S2sMeta> &infos, const std::string &name, int group)
{
 	std::map<int64_t, S2sMeta>::iterator it = m_sid2Metas.begin();
	for(; it != m_sid2Metas.end(); ++it)
	{
		S2sMeta& tmp = it->second;
		if( ((tmp.name == name ) || (name.empty())) && ((tmp.groupId == group) || (group ==0)) )
		{
			infos.push_back(tmp);
		}
	}
	
	if(name.empty())
	{
		S2SDLOG(Info, "name empty, group = %d, size = %u", group, infos.size());
	}
	else
	{
		S2SDLOG(Info, "name =%s, group = %d, size = %u", name.c_str(), group, infos.size());
	}

	return true;
}

bool CS2SClient::dispatchByServerId(int64_t serverId, core::Sender &objSender)
{
	sid_cid_t::iterator it = sid2cid.find(serverId);
	if (it != sid2cid.end())
	{
		if (dispatchById(it->second, objSender))
		{
			//USE OLD-PRO
			return true;
		}
	}
	else
	{
		IConn *c = connectServerId(serverId);
		if (c)
		{
			c->send(objSender);
			return true;
		}
		else
		{
			S2SDLOG(Error, "SV-create conn error serverid:%ju", serverId);
		}
	}
	return false;
}

bool CS2SClient::dispatchByServerId(int64_t serverId, std::string& strPacket)
{
	sid_cid_t::iterator it = sid2cid.find(serverId);
	if (it != sid2cid.end())
	{
		IConn* pConn = getConnectById(it->second);
		if(pConn)
		{
			pConn->sendBin(strPacket.data(), strPacket.size(), 0);
			return true;
		}
	}
	else
	{
		IConn *c = connectServerId(serverId);
		if (c)
		{
			c->sendBin(strPacket.data(), strPacket.size(), 0);
			return true;
		}
		else
		{
			S2SDLOG(Error, "SV-create conn error serverid:%ju", serverId);
		}
	}
	return false;
}

bool CS2SClient::dispatchByConnid(uint32_t uConnid, core::Sender &objSender)
{
	return dispatchById(uConnid, objSender);
}

bool CS2SClient::dispatchByIpPort(const std::string& strIp, uint16_t uPort, core::Sender &objSender)
{
	// 找已有连接
	uint64_t uKey = __toKey(sox::aton_addr(strIp), uPort);
	MAP_IPPORT_CID_t::iterator iterKey = m_mapIpPortConnId.find(uKey);
	if (iterKey != m_mapIpPortConnId.end())
	{
		dispatchById(iterKey->second, objSender);
		return true;
	}

	// 创建新连接
	IConn* pConn = createClientConn(strIp, uPort, getLinkHandler(), this);
	if (pConn)
	{
		m_mapIpPortConnId[uKey] = pConn->getConnId();
		pConn->send(objSender);
		S2SDLOG(Notice, "server:%s:%u conn:%p-%u", strIp.c_str(), uPort, pConn, pConn->getConnId());
		return true;
	}
	else
	{
		S2SDLOG(Error, "failed to  CreateClientConn ip:%s port:%u", strIp.c_str(), uPort);
		return false;
	}
}

core::IConn* CS2SClient::connectServerId(int64_t serverId)
{
	S2sMeta info;
	if (getServer(info, serverId) == false)
	{
		S2SDLOG(Error, "Can't find serverId:%ju", serverId);
		return NULL;
	}

	// 从info中获取CTL/CNC IP
	S2sDataDecoder data(info.data);
	
	std::map<S2S::ISPType, uint32_t> ips;
	data.readIpList(ips);

	uint32_t port;
	data.readTcpPort(port);

	std::string ip = s2sd::CS2SServerFunc::GetBestPeerIp(server->getIps(), ips);
	
	if(ip.empty())
	{
		S2SDLOG(Error, "empty ip. serverId:%ju", serverId);
		return NULL;
	}

	IConn *conn = createClientConn(ip, port, getLinkHandler(), this);
	if (conn)
	{
		sid2cid[serverId] = conn->getConnId();
		S2SDLOG(Notice, "serverId:%ju conn:%p connId:%u", serverId, conn, conn->getConnId());
	}
	else
	{
		S2SDLOG(Error, "SV-connect to daemon error:%ju", serverId);
	}

	return conn;
}

void CS2SClient::eraseConnect(core::IConn *pConn)
{
	if (NULL == pConn) return ;

	// 同时按IP:Port擦除连接
	uint32_t uPeerIp = pConn->getPeerIp();
	uint16_t uPeerPort = pConn->getPeerPort();
	uint64_t uKey = __toKey(uPeerIp, uPeerPort);
	MAP_IPPORT_CID_t::iterator it = m_mapIpPortConnId.find(uKey);
	if (it != m_mapIpPortConnId.end())
	{
		m_mapIpPortConnId.erase(it);
		S2SDLOG(Info, "peer %s:%u", sox::addr_ntoa(uPeerIp).c_str(), uPeerPort);
	}

	// 从sid2cid中移除相应连接
	uint32_t id = pConn->getConnId();
	for (sid_cid_t::iterator it = sid2cid.begin(); it != sid2cid.end();)
	{
		if (it->second == id)
		{
			sid2cid.erase(it++);
			S2SDLOG(Info, "peer serverId:%ju connId:%u %s:%u", it->first, id, sox::addr_ntoa(uPeerIp).c_str(), uPeerPort);
		}
		else
		{
			it++;
		}
	}

	MultiConnManagerImp::eraseConnect(pConn);
}

uint64_t CS2SClient::__toKey(uint32_t uIp, uint16_t uPort)
{
	return (((uint64_t)uIp << 32) | uPort );
}
