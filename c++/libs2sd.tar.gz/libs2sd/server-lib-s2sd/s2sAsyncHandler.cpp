#include "s2sAsyncHandler.h"
#include "common/core/ibase.h"
#include "core/sox/measure.h"
#include "core/corelib/WrapForwardBuffer.h"

#include <memory>
#include <boost/bind.hpp>
#include <boost/thread/tss.hpp>

#define REPORT_TIME_OUT 10 * 1000

using namespace core;
using namespace s2sd;

static boost::thread_specific_ptr<s2sd::WorkerInfo> sTSS;

CS2SAsyncHandler::CS2SAsyncHandler(){
	
	measureEnableMultiThread();
	select_timeout(REPORT_TIME_OUT);
	procSize = 0;
	dropedSize = 0;
	activeThreads = 0;
	queueLimit=((size_t)-1);
	workerId = 0;
}

CS2SAsyncHandler::~CS2SAsyncHandler() {
	joinAll();
}

void CS2SAsyncHandler::setQueueLimit(size_t s) {
	queueLimit = s;
}

int CS2SAsyncHandler::onData(const char* data, size_t size, IConn *conn, int type) {
	WrapForwardBuffer fb(data, size);

	while (!fb.empty()) {
		if (fb.size() < 4)
			break; // need more
		uint32_t length = Request::peeklen(fb.data());
		if( length<10 || length> (100*1024*1024) )
		{
			return -1;
		}
		if (fb.size() < length)
			break; // need more

		incProc(length);
		if(get_queue_size()<queueLimit)
		{
			requests.push(new RequestData(fb.data(), length, conn->getConnId()));
		}
		else
		{
			dropedSize=(dropedSize+1);
		}	
		
		fb.erase(length);
	}

	return fb.offset();
}


CS2SAsyncHandler::Worker::Worker(CS2SAsyncHandler * ws, uint32_t id) :
m_sd(TS_INIT), m_thread(new boost::thread(boost::bind(&CS2SAsyncHandler::Worker::run, this, ws))) {
	m_id = id;
}

CS2SAsyncHandler::Worker::~Worker() {
	m_thread->join();
}
void CS2SAsyncHandler::Worker::run(CS2SAsyncHandler * ws) {
	sTSS.reset(new s2sd::WorkerInfo(m_id, 0));

	while (true) {
		m_sd = TS_GET_TASK;
		std::auto_ptr<RequestData> task(ws->popRequest());
		if (!task.get())
			break; // 得到一条NULL消息就停止
		m_sd = TS_RUNING;
		ws->beginProc();
		try{						
			Request request= Request(task->msg.data(), task->msg.length());
			request.head();
			sTSS.get()->uConnId = task->connId;
			S2SDLOG(Debug, "workerId:%u connId:%u uri:%u", m_id, task->connId, request.getUri());
			IWriter *writer = ws->appContext->requestDispatch(request, NULL);
			//if(ws->getAfterProcessFilter()){
			//	ws->getAfterProcessFilter()->process(request);
			//}
			if (writer) writer->flush();
			sTSS.get()->uConnId = 0;
		}catch ( std::exception & ex ){
			S2SDLOG(Error, "thread run: %s", ex.what());
		}
		ws->endProc();
	}
	m_sd = TS_ZOMBIE;
	ws->OnWorkerExit(this);
}
ThreadState CS2SAsyncHandler::Worker::sd() {
	return m_sd;
}

bool  CS2SAsyncHandler::isS2SWorkerHandler()
{
	return (NULL != sTSS.get());
}
uint32_t CS2SAsyncHandler::getS2SWorkerConnId()
{
	return (NULL != sTSS.get()) ? sTSS.get()->uConnId : 0;
}
void CS2SAsyncHandler::setWorkerCount(size_t count) {
	size_t curcount = workerSize();
	if (count > curcount) {
		size_t inc = count - curcount;
		for (size_t i = 0; i < inc; ++i)
			increaseWorker();
	} else if (count < curcount) {
		size_t dec = curcount - count;
		for (size_t i = 0; i < dec; ++i)
			decreaseWorker();
	}
}

void CS2SAsyncHandler::increaseWorker() {
	scoped_lock_t lock(workerMutex);
	workers.insert(new Worker(this, ++workerId));
}

void CS2SAsyncHandler::decreaseWorker() {
	requests.push(NULL);
}

size_t CS2SAsyncHandler::workerSize() const {
	scoped_lock_t lock(workerMutex);
	return workers.size();
}

void CS2SAsyncHandler::OnWorkerExit(Worker * w) {

	scoped_lock_t lock(workerMutex);
	workers.erase(w);
	zombie.insert(w);
	if (workers.empty())
		m_cond.notify_all();

}

void CS2SAsyncHandler::joinZombie() {
	scoped_lock_t lock(workerMutex);
	for (Workers::iterator i = zombie.begin(); i != zombie.end(); ++i)
		delete (*i);
	zombie.clear();
}

void CS2SAsyncHandler::joinAll() {
	size_t size = workerSize();
	while (size -- > 0)
		decreaseWorker();
	{
		scoped_lock_t lock(workerMutex);
		while (!workers.empty())
			m_cond.wait(lock);
	}
	joinZombie();
}

void CS2SAsyncHandler::handle(int sig)
{
	measureSetQueueSize(requests.size());
	measureSetActiveThread(activeThreads);
	measureSetDropedRequest(dropedSize);

	S2SDLOG(Notice, "request:%u proc:%u dropped:%u active:%u", requests.size(), procSize,dropedSize, activeThreads);
#ifdef DYNAMIC_LOG
//	if (requests.size() > 100 || procSize > 6000)
	if (requests.size() > 100)
	{
		LogLevelNoticeSigHandler(1);
	}else{
		LogLevelDebugSigHandler(1);
	}
#endif
	scoped_lock_t lock(procMutex);
	procSize = 0;
	dropedSize = 0;
	select_timeout(REPORT_TIME_OUT);
}

void CS2SAsyncHandler::beginProc(){
	scoped_lock_t lock(procMutex);
	activeThreads++;
}

void CS2SAsyncHandler::endProc(){
	scoped_lock_t lock(procMutex);
	activeThreads--;
	++procSize;
}

void CS2SAsyncHandler::set_queue_limit(size_t limit)
{
	queueLimit=limit;
}
size_t CS2SAsyncHandler::get_queue_size()
{
	return requests.size();
}

