#pragma once

#include "is2sServer.h"
#include "server_common/server-lib/DaemonServer.h"
#include "server_common/config/IServerConfig.h"

namespace core
{
	class S2SServer : public IS2SServer,
					  public Singleton<S2SServer>
	{
	public:
		S2SServer();
		~S2SServer();

		bool init(IServer* p);
		virtual bool startSV();
		virtual uint16_t getPort();
		virtual std::vector<uint16_t> getPorts();

	protected:
		IServer* m_pServer;
	};
}
