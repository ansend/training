#include "s2sLib3Writer.h"
#include "s2sAsyncHandler.h"
#include "s2sdEnv.h"

using namespace core;

void CS2SLib3Writer::answer(uint32_t uri, const sox::Marshallable &obj)
{
    bool isSucc = false;
    uint32_t uConnId = s2sd::getS2SConnId();
    if (0 != uConnId)
    {
    	core::Sender sdr(uri, obj);
       	s2sd::getRouter()->dispatch(uConnId, sdr);
        isSucc = true;
    }

	int iLevel = (isSucc == false) ? Warn : Info;
	S2SDLOG(iLevel, "uri:%u, result =%u", uri,isSucc);
}

