#include "s2sServer.h"
#include "s2sdEnv.h"

using namespace core;

S2SServer::S2SServer()
: m_pServer(NULL)
{
}

S2SServer::~S2SServer()
{
}

bool S2SServer::init(IServer* p)
{
    m_pServer = p;
    return true;
}
bool S2SServer::startSV()
{
	m_pServer->startSV();
    return true;
}

uint16_t S2SServer::getPort()
{
	return m_pServer->getPorts().front();
}

std::vector<uint16_t> S2SServer::getPorts()
{
	return m_pServer->getPorts();
}
