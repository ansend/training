#include "s2sdEnv.h"
#include "s2sServer.h"
#include "s2sClient.h"
#include "s2sDataHandler.h"
#include "s2sAsyncHandler.h"
#include "s2sAppContext.h"
#include "StaticHostInfo.h"

#include "core/corelib/MfcAppContext.h"
#include "core/corelib/WrapServerStart.h"

namespace core {
namespace s2sd {

static int s2sdType = S2SD_SINGLETHREAD;

bool init(const std::string & name, const std::string& key, int type, int serverPort, int grpId, int threadNum,IServer* server)
{
    S2SDLOG(Notice, "set s2sName:%s s2sKey:%s type:%d", name.c_str(), key.c_str(), type);
    WrapServerStart::init();
    s2sdType = type;

    // instance
    CS2SClient::Instance();
    S2SServer::Instance();
    getRouter();    
    getDataHandler();
    getS2sSvrInfo();

    // static conf
    {
        StaticHostInfo   gHostInfo;
		uint32_t groupId = grpId;
		if(groupId == 0)
		{
        	groupId = gHostInfo.getPriGroupId();
		}
		
        ISP2IP_map_t isp2ipMap = gHostInfo.getIsp2Ip();
        std::map<S2S::ISPType, uint32_t> ips;
        std::ostringstream oss;
        // dirty work
        for (ISP2IP_map_t::iterator ispIt = isp2ipMap.begin(); ispIt != isp2ipMap.end(); ++ispIt)
        {
            S2S::ISPType isp = (S2S::ISPType)ispIt->first;
            ips[isp] = ispIt->second;
            oss << "(" << isp << "," << sox::addr_ntoa(ispIt->second) << "),";
        }
        S2SServer::Instance()->setGroupId(groupId);
        S2SServer::Instance()->setIp(ips);
        S2SDLOG(Notice, "load groupId:%u isp2ip:%s", groupId, oss.str().c_str());
    }

    CS2SAppContext::Instance()->setWriter(getRouter());
    // set all aware/watcher    
    if (S2SD_SINGLETHREAD == s2sdType)
    {
        CS2SDataHandler::Instance()->setAppContext(CS2SAppContext::Instance());
    }
    else
    {
        CS2SAsyncHandler::Instance()->setAppContext(CS2SAppContext::Instance());
        CS2SAsyncHandler::Instance()->setWorkerCount(threadNum); // 默认15个s2sd worker线程
    }
	
	IServer* pServer = server;
	if(pServer == NULL)
	{
	    SimplePrxServer * simpleServer = new SimplePrxServer();
	    simpleServer->refreshPort(serverPort);  // 默认4w端口
	    simpleServer->setConnManager(CS2SClient::Instance());
	    simpleServer->setLinkEvent(CS2SClient::Instance());
	    simpleServer->setLinkHandler(getDataHandler());

		pServer = simpleServer;
	}
    S2SServer::Instance()->init(pServer);
    S2SServer::Instance()->setS2sNameKey(name, key);

    CS2SClient::Instance()->setClientConnCreator(getConnCreator());
    CS2SClient::Instance()->setServerConnCreator(getConnCreator());
    CS2SClient::Instance()->SetS2SServer(S2SServer::Instance());
    CS2SClient::Instance()->setLinkHandler(getDataHandler());
    CS2SClient::Instance()->addExtKey("s2sdPid", (uint32_t)::getpid());

    getRouter()->SetS2SDispatcher(CS2SClient::Instance());
    getS2sSvrInfo()->SetS2SServer(S2SServer::Instance());
    getS2sSvrInfo()->setS2SClient(CS2SClient::Instance());
    return true;
}
void start()
{
    if (!S2SServer::Instance()->startSV()) {
        S2SDLOG(Fatal, "start s2s server failed");
        ::exit(-1);
    }
    if (!CS2SClient::Instance()->Start()) {
        S2SDLOG(Fatal, "start s2s client failed!");
        ::exit(-2);
    }

    // 业务的其它部分初始化可能还没完成
    //WrapServerStart::run();
}

IS2SServer *      getServer()
{
    return S2SServer::Instance();
}
IS2SClient *      getClient()
{
    return CS2SClient::Instance();
}
IS2SRouter  *      getRouter()
{
    if (S2SD_SINGLETHREAD == s2sdType)
    {
        return S2SRouter::Instance();
    }
    else
    {
        return S2SAsyncRouter::Instance();
    }
}

IS2SDispatcher *  getDispatcher()
{
    return CS2SClient::Instance();
}
ICS2SServersInfo *  getS2sSvrInfo()
{
    if (S2SD_SINGLETHREAD == s2sdType)
    {
        return CS2SServersInfo::Instance();
    }
    else
    {
        return CS2SServersInfoMT::Instance();
    }
}
IConnManager *    getConnManager()
{
    return CS2SClient::Instance();
}
ILinkEvent *      getLinkEvent()
{
    return CS2SClient::Instance();
}

ILinkHandler *    getDataHandler()
{
    if (S2SD_SINGLETHREAD == s2sdType)
    {
        return CS2SDataHandler::Instance();
    }
    else
    {
        return CS2SAsyncHandler::Instance();
    }    
}
IAppContextEx *   getAppContext()
{
    return CS2SAppContext::Instance();
}
InnerConnCreator * getConnCreator()
{
    static InnerConnCreator sConnCreator;
    return &sConnCreator;
}

bool isS2SLibConn(core::IConn * conn)
{
    if (conn)
    {
        return (conn->getLinkEvent() == getLinkEvent());
    }
    return false;
}
bool isS2SOnHandle()
{
    if (S2SD_SINGLETHREAD == s2sdType)
    {
        return CS2SDataHandler::Instance()->isOnHandle();
    }
    else
    {
        return CS2SAsyncHandler::Instance()->isS2SWorkerHandler();
    }
}
uint32_t getS2SConnId()
{
    if (S2SD_SINGLETHREAD == s2sdType)
    {
        return CS2SDataHandler::Instance()->getCurConnId();
    }
    else
    {
        return CS2SAsyncHandler::Instance()->getS2SWorkerConnId();
    }    
}

}
}