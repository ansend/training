#pragma once

#include <pthread.h>

/*
 *
 * һ��д���ȶ�д����ʵ�֣��ʺ϶��߳�Ƶ��ʹ�ù����������߳�������ռ�������
 *
*/

namespace core 
{
    namespace s2sd 
    {

        class CRWLockMutex 
        {
        private :
            pthread_mutex_t cnt_mutex;
            pthread_cond_t rw_cond;
            int rd_cnt, wr_cnt;
        public :
            CRWLockMutex(): rd_cnt(0),wr_cnt(0)
            {
                pthread_mutex_init(&cnt_mutex, NULL);
                pthread_cond_init(&rw_cond, NULL);
            }
            ~CRWLockMutex()
            {
                pthread_mutex_destroy(&cnt_mutex);
                pthread_cond_destroy(&rw_cond);
            }
            // ������ ����
            void get_shared_lock()
            {
                pthread_mutex_lock(&cnt_mutex);

                while (wr_cnt >0)
                {
                    pthread_cond_wait(&rw_cond,&cnt_mutex);
                }
                rd_cnt++;
                
                pthread_mutex_unlock(&cnt_mutex);
            }
            void release_shared_lock()
            {
                pthread_mutex_lock(&cnt_mutex);

                if(rd_cnt>0)
                {
                    rd_cnt--;
                }
                
                if (0 == rd_cnt)
                {
                    pthread_cond_signal(&rw_cond);
                }
                
                pthread_mutex_unlock(&cnt_mutex);
            }

            // ��ռ�� д��
            void get_exclusive_lock()
            {
                pthread_mutex_lock(&cnt_mutex);
                wr_cnt++;

                while (rd_cnt>0)
                {
                    pthread_cond_wait(&rw_cond,&cnt_mutex);
                }

                pthread_mutex_unlock(&cnt_mutex);
            }
            void release_exclusive_lock()
            {
                pthread_mutex_lock(&cnt_mutex);

                if(wr_cnt>0)
                {
                    wr_cnt--;
                }
                pthread_cond_broadcast(&rw_cond);
                
                pthread_mutex_unlock(&cnt_mutex);
            }

        };

        class CWritePerf_RWLock
        {
        public:
            CWritePerf_RWLock() : m_pMutex(NULL){}
            CWritePerf_RWLock(CRWLockMutex* pMutex, bool bWriteLock = false) 
                : m_pMutex(pMutex), m_bIsWriteLock(bWriteLock)
            {
                if (!m_pMutex)
                {            
                    return;
                }

                if (m_bIsWriteLock)
                {
                    m_pMutex->get_exclusive_lock();  
                }
                else
                {
                    m_pMutex->get_shared_lock();
                }
            }

            ~CWritePerf_RWLock()
            {
                if (!m_pMutex)
                {            
                    return;
                }
                
                if (m_bIsWriteLock)
                {
                    m_pMutex->release_exclusive_lock();  
                }
                else
                {
                    m_pMutex->release_shared_lock(); 
                }
            }
        private:
            CRWLockMutex* m_pMutex;
            bool m_bIsWriteLock;
        };
    }
}
