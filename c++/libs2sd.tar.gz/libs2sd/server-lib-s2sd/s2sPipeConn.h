#pragma once

#include "s2sPublic.h"

namespace core {
  
class s2sPipeConn: public core::IConn, public sox::Socket
{
public:
  s2sPipeConn();
  virtual ~s2sPipeConn();

  bool watch(int fd, core::ILinkHandler* handler);

public:
  virtual void handle(int);
  virtual void onRead();

	virtual void send(core::Sender &resp){};
	virtual void sendBin(const char *data, size_t sz, uint32_t uri){};
	virtual void setTimeout(int tm){};
	virtual void *getData(){return NULL;};
  virtual void setEncKey(const unsigned char *key, size_t len){};

private:

  core::ILinkHandler* m_pHandler;
};

}