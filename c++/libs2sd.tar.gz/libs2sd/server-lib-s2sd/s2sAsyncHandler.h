#pragma once

#include "common/core/ilink.h"
#include "common/core/iserver.h"
#include "core/corelib/AStatLinkHandler.h"
#include "server_common/dblib/TMessageQueue.h"
#include "s2sPublic.h"

#include <boost/thread/thread.hpp>
#include <deque>

namespace core {
namespace s2sd {
	struct RequestData {
		std::string msg;
		uint32_t connId;
		RequestData(const char * d, size_t sz, uint32_t cid) :
			msg(d, sz), connId(cid) { }
	};
	typedef std::deque<RequestData *> request_list_t;

	enum ThreadState
	{
		TS_INIT = 0, // thread not start
		TS_GET_TASK = 1, // wait for task
		TS_RUNING = 2, // running
		TS_ZOMBIE = 3, // thread exit but not join
		TS_USER_DEFINE = 100,
	};

	struct WorkerInfo
	{
		uint32_t uWorkerId;
		uint32_t uConnId;
		WorkerInfo(uint32_t wId, uint32_t cId) :
			uWorkerId(wId), uConnId(cId) {}
	};
}

class CS2SAsyncHandler:	public core::AStatLinkHandler,
						public core::IAppContextAware,
						public sox::Handler,
						public Singleton<CS2SAsyncHandler>
	{
private:
	class Worker : private boost::noncopyable {
	public:
		explicit Worker(CS2SAsyncHandler * ws, uint32_t id);
		~Worker();
		void run(CS2SAsyncHandler * ws);
		s2sd::ThreadState sd();
	protected:
		s2sd::ThreadState m_sd;
		std::auto_ptr<boost::thread> m_thread;
		uint32_t m_id;
	};

	typedef TMessageQueue<s2sd::request_list_t> request_queue_t;
	request_queue_t requests;
	//result_queue_t results;
	core::IAppContextEx *parent;

	typedef boost::mutex::scoped_lock scoped_lock_t;
	mutable boost::mutex workerMutex;
	mutable boost::condition m_cond;

	typedef std::set<Worker*> Workers;
	Workers workers;
	Workers zombie;

	size_t workerSize() const;

	void handle(int sig);

	int activeThreads;
	int procSize;
	volatile int dropedSize;
	mutable boost::mutex procMutex;
public:
	CS2SAsyncHandler();
	~CS2SAsyncHandler();
	virtual int onData(const char*, size_t, core::IConn *conn, int type);

	void setWorkerCount(size_t count);
	bool  isS2SWorkerHandler();
	uint32_t getS2SWorkerConnId();

	void increaseWorker();
	void decreaseWorker();

	s2sd::RequestData *popRequest() {
		return requests.pop();
	}

	void OnWorkerExit(Worker * w);

	void joinZombie();

	void joinAll();

	void beginProc();
	void endProc();

	void setQueueLimit(size_t s);
public:
	void set_queue_limit(size_t limit);
	size_t get_queue_size();
	volatile size_t queueLimit;
	uint32_t workerId;
};

}
