#include "s2sLib3Target.h"
#include "s2sAsyncHandler.h"
#include "s2sdEnv.h"

using namespace core;

enum __ROUTEBY__
{
    RB_FAILED     = 0,
    RB_S2SD,
    RB_DAEMON
};
static const char * sRouteBy[] =
{
    "failed!",
    "s2sd",
    "daemon"
};

void CS2SLib3Target::setDaemonPointer(core::SimpleWriter * pW, core::IGroupNameDispatcher * pD)
{
    SimpleWriterAware::setSimpleWriter(pW);
    IGroupNameDispatcherAware::setGroupNameDispatcher(pD);
}

void CS2SLib3Target::setExtPacker(IWriter* packer)
{
	pExtPacker.reset(packer);
}


// writer API
void CS2SLib3Target::answer(uint32_t uri, uint16_t res)
{
    answer(uri, res, sox::Voidmable());
}
void CS2SLib3Target::answer(uint32_t uri, uint16_t res, const sox::Marshallable & obj)
{
    uint32_t uBy = RB_FAILED;
    uint32_t uConnId = s2sd::getS2SConnId();
    if (0 != uConnId)
    {
    	if(pExtPacker.get() == NULL)
    	{
        	core::Sender sdr(uri, obj);
        	sdr.setResCode(res);
       		s2sd::getRouter()->dispatch(uConnId, sdr);
        	uBy = RB_S2SD;
    	}
		else
		{
			pExtPacker->answer(uri, obj);
			uBy = RB_S2SD;
		}
    }
    else if (NULL != writer)
    {
        InstanceTarget::find_answer_writer()->answer(uri, obj);
        uBy = RB_DAEMON;
    }
    
    int iLevel = (uBy == RB_FAILED) ? Warn : Info;
    S2SDLOG(iLevel, "uri:%u res:%u %s", uri, res, sRouteBy[uBy]);
}

// dispatcher API
int CS2SLib3Target::dispatchByGroupName(const std::string & serverName, int groupId, uint32_t uri, sox::Marshallable & obj)
{
    int iRet = -1;
    int64_t uServerId = -1;
    uint32_t uBy = RB_FAILED;
    if (s2sd::getClient()->isNotifySuffix(serverName))
    {
        if (groupId == -1)
        {
            uServerId = s2sd::getS2sSvrInfo()->RandomServerIDByName(serverName);
        }
        else
        {
            uServerId = s2sd::getS2sSvrInfo()->RandomServerIDByNameGroup(serverName, groupId);
        }
        if (-1 != uServerId)
        {
            s2sd::getRouter()->dispatch(uServerId, uri, obj);
            iRet = 0;            
        }
        else
        {
            S2SDLOG(Warn, "cannt find s2s name:%s server", serverName.c_str());
        }
        uBy = RB_S2SD;
    }
    else if (NULL != gnNameDispatcher)
    {
        iRet = gnNameDispatcher->dispatchByGroupName(serverName, groupId, uri, obj);
        uBy = RB_DAEMON;
    }

    int iLevel = (uBy == RB_FAILED) ? Warn : Info;
    S2SDLOG(iLevel, "name:%s group:%u uri:%u ret:%d %s-%llx",
        serverName.c_str(), groupId, uri, iRet, sRouteBy[uBy], uServerId);
    return iRet;
}
int CS2SLib3Target::dispatchByServerID(int64_t serverId, uint32_t uri, sox::Marshallable & obj)
{
    int iRet = -1;
    uint32_t uBy = RB_FAILED;
    if (s2sd::getS2sSvrInfo()->IsServerIDExist(serverId))
    {
        s2sd::getRouter()->dispatch(serverId, uri, obj);
        iRet = 0;
        uBy = RB_S2SD;
    }
    else if (NULL != gnNameDispatcher)
    {
        iRet = gnNameDispatcher->dispatchByServerID(serverId, uri, obj);
        uBy = RB_DAEMON;
    }

    int iLevel = (uBy == RB_FAILED) ? Warn : Info;
    S2SDLOG(iLevel, "serverId:%llx uri:%u ret:%d %s", serverId, uri, iRet, sRouteBy[uBy]);
    return iRet;
}


int CS2SLib3Target::dispatchToAll(const std::string &name, int groupId, uint32_t uri, sox::Marshallable& obj)
{
    int iRet = -1;
    uint32_t uBy = RB_FAILED;
    if (s2sd::getClient()->isNotifySuffix(name))
    {
		std::vector<int64_t> svrs = s2sd::getS2sSvrInfo()->GetServersByNameGroup(name,groupId);
	
		for(size_t i = 0; i< svrs.size(); ++i)
		{
        	s2sd::getRouter()->dispatch(svrs[i], uri, obj);
		}
        iRet = 0;
        uBy = RB_S2SD;
    }
    else if (NULL != gnNameDispatcher)
    {
        iRet = gnNameDispatcher->dispatchToAll(name, groupId, uri, obj);
        uBy = RB_DAEMON;
    }

    int iLevel = (uBy == RB_FAILED) ? Warn : Info;
    S2SDLOG(iLevel, "serverName:%s groupId:%d uri:%u ret:%d %s", name.c_str(), groupId,uri, iRet, sRouteBy[uBy]);
    return iRet;	
}

