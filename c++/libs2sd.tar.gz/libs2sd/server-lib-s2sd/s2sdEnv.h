#pragma once

#include "s2sPublic.h"
#include "is2sClient.h"
#include "is2sServer.h"
#include "s2sRouter.h"
#include "s2sSvrInfo.h"

namespace core {
namespace s2sd {

enum
{
    S2SD_SINGLETHREAD,      // 单线程版, 适用于server-lib和server-lib2
    S2SD_MULTITHREAD_LIB3,  // 多线程版, 适用于server-lib3
    S2SD_MULTITHREAD_DB,    // 多线程版, 适用于dbdlib
};

bool init(const std::string & name, const std::string& key, int type,int serverPort = 40000, int grpId = 0, int threadNum = 15,IServer* server = NULL);
void start();

IS2SServer *        getServer();
IS2SClient *        getClient();
IS2SRouter  *       getRouter();

IS2SDispatcher *    getDispatcher();
ICS2SServersInfo *  getS2sSvrInfo();
IConnManager *      getConnManager();

ILinkHandler *      getDataHandler();
IAppContextEx *     getAppContext();
ILinkEvent *        getLinkEvent();
InnerConnCreator *  getConnCreator();

// 单线程版本接口
bool isS2SLibConn(core::IConn * conn);
// 线程安全版本接口
bool isS2SOnHandle();
uint32_t getS2SConnId();

// 注意route等外层包会自动添加处理, 业务不用添加
// 注意lib3 addUriEntries 一定要先于 sf->getAppContext()->addEntry
template <typename UH>
void addUriEntries(UH * pApp)
{
    core::FormEntry * es = UH::getFormEntries();
    getAppContext()->addEntry(es, pApp, NULL);

    // for log
    int count = 0;
    uint32_t uri = 0;
    while ((uri = es[count].uri) != 0)
    {
        ++count;
        S2SDLOG(Notice, "add uri:%s app:%p", uri2str(uri), pApp);
    }
    S2SDLOG(Notice, "add app:%p and uri count:%u", pApp, count);
}

inline std::string connpeer(core::IConn * conn)
{
    uint32_t uIp = conn->getPeerIp();
    struct in_addr addr;
    ::memcpy(&addr, &uIp, 4);
    char buf[128];
    ::snprintf(buf, sizeof(buf), "%s:%u", ::inet_ntoa(addr), conn->getPeerPort());
    return std::string(buf); 
}

// s2sd::getSid替换旧daemon的DomainName::getSid
inline bool getSid(const std::string & query, uint64_t & out)
{
    std::string param;
    std::size_t pos = query.find_last_of('/');
    if (pos != std::string::npos)
    {
        param = query.substr(pos + 1);
    }

    out = ::strtoull(param.data(), NULL, 10);
    if (out == 0 && param != "0")
    {
        return false;
    }
    return true;
}

}
}