#include "s2sAppContext.h"
#include "s2sdEnv.h"

using namespace core;

BEGIN_FORM_MAP(CS2SAppContext)
    ON_LINK(server::router::PRouter, &CS2SAppContext::route)
    ON_LINK(server::router::PServerIdRouter, &CS2SAppContext::routeS)
END_FORM_MAP()

CS2SAppContext::CS2SAppContext()
{
    addEntry(CS2SAppContext::getFormEntries(), this, NULL);
}

void CS2SAppContext::addEntry(FormEntry * es, void *target, IWriterAware *inf)
{
    if (inf)
    {
        inf->setWriter(getWriter());
    }

    int i = 0;    
    //target maybe null
    while (es[i].uri != 0)
    {
        if (entries.find(es[i].uri) != entries.end())
        {
            S2SDLOG(Error, "dupicate form entry:%u", es[i].uri);
            assert(false);
        }

        // 由于旧daeamon有些appContext会改变FormEntry, 所以自己new一个
        FormEntry * pFE = new FormEntry();
        pFE->uri = es[i].uri;
        pFE->requestForm._f = es[i].requestForm._f;
        pFE->type = es[i].type;
        pFE->proc = es[i].proc;
        pFE->target = (PHClass *)target;

        entries[es[i].uri] = pFE;

        ++i;
    }
}

void CS2SAppContext::route(server::router::PRouter *rt, IConn *conn)
{
    Request rq(rt->load.data(), rt->load.length());
    rq.setUri(rt->ruri);
    rq.setResCode(rt->resCode);
    rq.setKey(rt->from);
    rq.to = rt->to;

    S2SDLOG(Debug, "from:%s uri:%u payload:%u", rt->from.c_str(), rt->ruri, rt->load.length());
    s2sd::getRouter()->SetFrom(rt->from);
    requestDispatch(rq, conn);
    s2sd::getRouter()->SetFrom("");
}
void CS2SAppContext::routeS(server::router::PServerIdRouter *rt, IConn *conn)
{
    Request rq(rt->load.data(), rt->load.length());
    rq.setUri(rt->ruri);
    rq.setResCode(rt->resCode);
    rq.setKey(rt->from);

    S2SDLOG(Debug, "from:%s uri:%u payload:%u", rt->from.c_str(), rt->ruri, rt->load.length());
    s2sd::getRouter()->SetFrom(rt->from);
    requestDispatch(rq, conn);
    s2sd::getRouter()->SetFrom("");
}