#pragma once

#include "core/corelib/MultiConnManagerImp.h"
#include "s2sPipeConn.h"
#include "is2sServer.h"
#include "is2sClient.h"

namespace core
{
	class CS2SClient : public core::ILinkHandler,
					   public IS2SServerAware,
					   public IS2SClient,
					   public IS2SDispatcher,
					   public core::ILinkHandlerAware,
					   public core::MultiConnManagerImp,
					   public Singleton<CS2SClient>
	{
	public:
		CS2SClient();
		virtual ~CS2SClient();

		// IEventSource
		virtual int onData(const char*, size_t, core::IConn *conn, int type = 0);

		// ע���Լ�����Ȥ�ķ�����(�Է�����ǰ׺��ʶ) NOTE: ��Ҫ��start֮ǰ����
		virtual void addNotifySuffix(const std::string& suffix);
		virtual void addNotifySuffix(const std::string& suffix, int32_t group);
		// �ǲ����Ѿ���ע�ķ���
        virtual bool isNotifySuffix(const std::string & suffix);

		// �����Զ�������
		virtual void addExtKey(const std::string& key, const std::string& value);
		virtual void addExtKey(const std::string& key, uint32_t value);
		
		// ������������
		virtual int setMine(void);				// addExtKey֮�������Ч
		virtual void reCreateMetaData(void);	// ����֮ǰ��addExtKey

		// IS2SClient interface
		virtual void watch(IS2SClientWatcher * w);
		virtual bool getServer(S2sMeta &info, int64_t srvId);
		virtual bool getServers(std::vector<S2sMeta> &infos, const std::string &name);
		virtual bool getServersByGroup(std::vector<S2sMeta> &infos, const std::string &name, int group);
		virtual bool dispatchByServerId(int64_t serverId, core::Sender &objSender);
		virtual bool dispatchByServerId(int64_t serverId, std::string& strPacket);
		virtual bool dispatchByConnid(uint32_t uConnid, core::Sender &objSender);
		virtual bool dispatchByIpPort(const std::string& strIp, uint16_t uPort, core::Sender &objSender);
		
		// MultiConnManager inherited functions
		virtual void eraseConnect(core::IConn *conn);

	public:
		bool Start();
		bool Stop();

	protected:
		core::IConn *connectServerId(int64_t serverId);
		uint64_t __toKey(uint32_t uIp, uint16_t uPort);
		
		virtual void setPackLimit(uint32_t sz){};
		bool watchFd(int watchFd);

	private:
		void handleS2sSessionStatus(S2sSessionStatus status);
		void handleUpdateMetas(std::vector<S2sMeta> updateMetas);
	private:
		int 		 m_s2sfd;
		s2sPipeConn* m_pipeConn;

		IMetaServer* m_pMetaServer;

		// ���Ĳ���
		std::vector<SubFilter> m_sunFilters;
		std::set<std::string> m_setSubFilter;
		std::set<std::string> m_setSubPattern;

		// �����ϴ�������
		S2sDataEncoder *m_pMetaData;

		// Server ID -> Connection ID
		typedef std::map<int64_t, uint32_t> sid_cid_t;
		sid_cid_t sid2cid;

		// Watcher�б�
		std::set<IS2SClientWatcher *> m_setWatchers;

		// ��IP:Port���ӹ���
		typedef std::map<uint64_t, uint32_t> MAP_IPPORT_CID_t;
		MAP_IPPORT_CID_t m_mapIpPortConnId;

		// ���涩��meta �б�
		std::map<int64_t, S2sMeta> m_sid2Metas;
		
		bool m_isStarted;
		// �Ƿ��Ѿ�BIND��
		bool m_isBind;

		// �Ƿ��Ѿ�refresh
		bool m_hasRefreshed;
	};
}
