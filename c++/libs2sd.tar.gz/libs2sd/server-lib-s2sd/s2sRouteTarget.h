#pragma once

#include "s2sPublic.h"
#include "server_common/server-lib/BRouteWriter.h"

namespace core {

// 通常用于替换旧daemon server-lib的IRouteTarget
// 一般不直接生成对象，业务继承直接使用接口
// 请初始化时设置setDaemonPointer, 内部根据上下文回复s2sd或旧daemon
class CS2SRouteTarget
{
public:
    static void setDaemonPointer(core::ABRouteWriter * pW, core::IServerIdDispatcher * pD);

    // writer API
    void answer(uint32_t uri, uint16_t res);
    void answer(uint32_t uri, uint16_t res, const sox::Marshallable & obj);

    void route(const std::string & serverName, uint32_t uri, const sox::Marshallable & obj);
    void route(const std::string & serverName, uint32_t uri, const std::string & str);

    void routeS(int64_t serverId, uint32_t uri, const sox::Marshallable & obj);
    void routeS(int64_t serverId, uint32_t uri, const std::string & str);

    // dispatcher API
    bool dispatchByServerIdSV(int64_t serverId, uint32_t uri, sox::Marshallable & obj);
    int64_t dispatchToServerRandom(const std::string & serverName, uint32_t uri, sox::Marshallable & obj);

    // 兼容旧daemon的router包
    std::string GetFrom();
    void SetFrom(const std::string &from) { assert(false); }

private:
    // old daemon pointer
    static core::ABRouteWriter * m_pDaemonWriter;
    static core::IServerIdDispatcher * m_pDaemonDispatcher;
};

}