#include "s2sRouteTarget.h"
#include "s2sDataHandler.h"
#include "s2sDaemonPack.h"
#include "s2sdEnv.h"

namespace core {

struct __StrObjHelper : public sox::Marshallable
{
    std::string str;
    __StrObjHelper(const std::string & s) : str(s) {}

    virtual void marshal(sox::Pack &pk) const {
        pk.push(str.data(), str.size());
    }
    virtual void unmarshal(const sox::Unpack &up) {
        str.assign(up.data(), up.size());
    }
};

enum __ROUTEBY__
{
    RB_FAILED     = 0,
    RB_S2SD,
    RB_DAEMON
};
static const char * sRouteBy[] =
{
    "failed!",
    "s2sd",
    "daemon"
};

core::ABRouteWriter * CS2SRouteTarget::m_pDaemonWriter = NULL;
core::IServerIdDispatcher * CS2SRouteTarget::m_pDaemonDispatcher = NULL;

void CS2SRouteTarget::setDaemonPointer(core::ABRouteWriter * pW, core::IServerIdDispatcher * pD)
{
    m_pDaemonWriter = pW;
    m_pDaemonDispatcher = pD;
    S2SDLOG(Notice, "set old daemon writer:%p dispatcher:%p", pW, pD);
}

void CS2SRouteTarget::answer(uint32_t uri, uint16_t res)
{
    answer(uri, res, sox::Voidmable());
}
void CS2SRouteTarget::answer(uint32_t uri, uint16_t res, const sox::Marshallable & obj)
{
    uint32_t uBy = RB_FAILED;
    uint32_t uConnId = s2sd::getS2SConnId();
    if (0 != uConnId)
    {
        core::Sender sdr(uri, obj);
        sdr.setResCode(res);
        s2sd::getRouter()->dispatch(uConnId, sdr);
        uBy = RB_S2SD;
    }
    else if (NULL != m_pDaemonWriter)
    {
        m_pDaemonWriter->answer(uri, res, obj);
        uBy = RB_DAEMON;
    }

    int iLevel = (uBy == RB_FAILED) ? Warn : Info;
    S2SDLOG(iLevel, "uri:%u res:%u %s", uri, res, sRouteBy[uBy]);
}

void CS2SRouteTarget::route(const std::string & serverName, uint32_t uri, const sox::Marshallable & obj)
{
    uint32_t uBy = RB_FAILED;
    int64_t uServerId = -1;
    if (s2sd::getClient()->isNotifySuffix(serverName))
    {
        uServerId = s2sd::getS2sSvrInfo()->RandomServerIDByName(serverName);
        if (-1 != uServerId)
        {
            server::router::PRouter rt;
            rt.to = serverName; 
            s2sd::packRoute(rt, uri, obj);
            s2sd::getRouter()->dispatch(uServerId, rt.uri, rt);            
        }
        else 
        {
            S2SDLOG(Warn, "cannt find s2s name:%s server", serverName.c_str());            
        }
        uBy = RB_S2SD;
    }
    else if (NULL != m_pDaemonWriter)
    {
        m_pDaemonWriter->route(serverName, uri, obj);
        uBy = RB_DAEMON;
    }

    int iLevel = (uBy == RB_FAILED) ? Warn : Info;
    S2SDLOG(iLevel, "name:%s uri:%u %s-%llx", serverName.c_str(), uri, sRouteBy[uBy], uServerId);
}
void CS2SRouteTarget::route(const std::string & serverName, uint32_t uri, const std::string & str)
{
    uint32_t uBy = RB_FAILED;
    int64_t uServerId = -1;
    if (s2sd::getClient()->isNotifySuffix(serverName))
    {
        uServerId = s2sd::getS2sSvrInfo()->RandomServerIDByName(serverName);
        if (-1 != uServerId)
        {
            server::router::PRouter rt;
            rt.to = serverName;
            s2sd::packRoute(rt, uri, str);
            s2sd::getRouter()->dispatch(uServerId, rt.uri, rt);
        }
        else 
        {
            S2SDLOG(Warn, "cannt find s2s name:%s server", serverName.c_str());            
        }
        uBy = RB_S2SD;
    }
    else if (NULL != m_pDaemonWriter)
    {
        m_pDaemonWriter->route(serverName, uri, __StrObjHelper(str));
        uBy = RB_DAEMON;
    }

    int iLevel = (uBy == RB_FAILED) ? Warn : Info;
    S2SDLOG(iLevel, "name:%s uri:%u %s-%llx", serverName.c_str(), uri, sRouteBy[uBy], uServerId);
}

void CS2SRouteTarget::routeS(int64_t serverId, uint32_t uri, const sox::Marshallable & obj)
{
    uint32_t uBy = RB_FAILED;
    bool bS2sId = s2sd::getS2sSvrInfo()->IsServerIDExist(serverId);
    if (bS2sId)
    {
        server::router::PServerIdRouter rt;
        rt.serverId = -1;
        s2sd::packRoute(rt, uri, obj);
        s2sd::getRouter()->dispatch(serverId, rt.uri, rt);
        uBy = RB_S2SD;
    }
    else if (NULL != m_pDaemonWriter)
    {
        m_pDaemonWriter->routeS(serverId, uri, obj);
        uBy = RB_DAEMON;
    }

    int iLevel = (uBy == RB_FAILED) ? Warn : Info;
    S2SDLOG(iLevel, "serverId:%llx uri:%u %s", serverId, uri, sRouteBy[uBy]);
}
void CS2SRouteTarget::routeS(int64_t serverId, uint32_t uri, const std::string & str)
{
    uint32_t uBy = RB_FAILED;
    bool bS2sId = s2sd::getS2sSvrInfo()->IsServerIDExist(serverId);
    if (bS2sId)
    {
        server::router::PServerIdRouter rt;
        rt.serverId = -1;
        s2sd::packRoute(rt, uri, str);
        s2sd::getRouter()->dispatch(serverId, rt.uri, rt);
        uBy = RB_S2SD;
    }
    else if (NULL != m_pDaemonWriter)
    {
        m_pDaemonWriter->routeS(serverId, uri, __StrObjHelper(str));
        uBy = RB_DAEMON;
    }

    int iLevel = (uBy == RB_FAILED) ? Warn : Info;
    S2SDLOG(iLevel, "serverId:%llx uri:%u %s", serverId, uri, sRouteBy[uBy]);
}

bool CS2SRouteTarget::dispatchByServerIdSV(int64_t serverId, uint32_t uri, sox::Marshallable & obj)
{
    bool bRet = false;
    uint32_t uBy = RB_FAILED;
    bool bS2sId = s2sd::getS2sSvrInfo()->IsServerIDExist(serverId);
    if (bS2sId)
    {
        bRet = s2sd::getRouter()->dispatch(serverId, uri, obj);
        uBy = RB_S2SD;
    }
    else if (NULL != m_pDaemonDispatcher)
    {
        bRet = m_pDaemonDispatcher->dispatchByServerIdSV(serverId, uri, obj);
        uBy = RB_DAEMON;
    }

    int iLevel = (!bRet || uBy == RB_FAILED) ? Warn : Info;
    S2SDLOG(iLevel, "serverId:%llx uri:%u %s", serverId, uri, sRouteBy[uBy]);
    return bRet;
}
int64_t CS2SRouteTarget::dispatchToServerRandom(const std::string & serverName, uint32_t uri, sox::Marshallable & obj)
{
    int64_t iSelectId = -1;
    int64_t uServerId = -1;
    uint32_t uBy = RB_FAILED;
    if (s2sd::getClient()->isNotifySuffix(serverName))
    {
        uServerId = s2sd::getS2sSvrInfo()->RandomServerIDByName(serverName);
        if (-1 != uServerId)
        {
            if (s2sd::getRouter()->dispatch(uServerId, uri, obj))
            {
                iSelectId = uServerId;
            }        
        }
        else
        {
            S2SDLOG(Warn, "cannt find s2s name:%s server", serverName.c_str());
        }
        uBy = RB_S2SD;
    }
    else if (NULL != m_pDaemonDispatcher)
    {
        iSelectId = m_pDaemonDispatcher->dispatchToServerRandom(serverName, uri, obj);
        uBy = RB_DAEMON;
    }

    int iLevel = (iSelectId == -1 || uBy == RB_FAILED) ? Warn : Info;
    S2SDLOG(iLevel, "name:%s uri:%u %s-%llx", serverName.c_str(), uri, sRouteBy[uBy], uServerId);
    return iSelectId;
}

std::string CS2SRouteTarget::GetFrom()
{
    if (s2sd::isS2SOnHandle())
    {
        return s2sd::getRouter()->GetFrom();
    }
    else if (NULL != m_pDaemonWriter)
    {
        return m_pDaemonWriter->GetFrom();
    }
    return "";
}

}