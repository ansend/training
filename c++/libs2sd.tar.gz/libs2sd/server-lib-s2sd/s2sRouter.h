#pragma once

#include "s2sPipeConn.h"
#include "s2sClient.h"

#include "server_common/server-lib/AutoTimer.h"
#include "core/corelib/RouterBase.h"

#include <boost/thread/mutex.hpp>
#include <boost/thread/tss.hpp>

namespace core
{
	class IS2SRouter :
		public core::IWriter,
		public IS2SDispatcherAware
	{
	public:
		IS2SRouter();
		virtual ~IS2SRouter();

		// from core::IWriter 请使用下面dispatch接口
		virtual void answer(uint32_t uri, const sox::Marshallable &obj) { assert(false); }
		virtual void answerErr(uint32_t uri, uint16_t ResCode) { assert(false); }
		virtual void stop() {}
		virtual int flush(IConn *ansConn = NULL) = 0;

		// ·¢ËÍÂã°ü
		bool dispatch(int64_t serverId, uint32_t uri, const sox::Marshallable &obj);
		bool dispatch(int64_t serverId, uint32_t uri, const std::string& str);
		bool dispatch(uint32_t uConnid, uint32_t uri, const sox::Marshallable &obj);

		bool dispatch(int64_t serverId, std::string& str);
		bool dispatch(int64_t serverId, core::Sender& sdr);
		bool dispatch(uint32_t uConnid, core::Sender & sdr);

		bool dispatch(const std::string& strIp, uint16_t uPort, uint32_t uUri, sox::Marshallable& obj);
		bool dispatch(const std::string& strIp, uint16_t uPort, uint32_t uUri, const std::string& str);
 
		// ·¢ËÍÆäËûÂí¼×±¨ÎÄ
		virtual std::string GetFrom()=0;
		virtual void SetFrom(const std::string &f)=0;

	protected:
		// ÄÚ²¿Ñ¹°üº¯Êý£¬¶àÏß³ÌÄ£Ê½ÏÂÔÊÐíoverride
		virtual bool _dispatch(int64_t serverId, uint32_t uri, const sox::Marshallable &obj)=0;
		virtual bool _dispatch(int64_t serverId, uint32_t uri, const std::string& str)=0;
		virtual bool _dispatch(uint32_t uConnid, uint32_t uri, const sox::Marshallable &obj)=0;
		virtual bool _dispatch(int64_t serverId, core::Sender& sdr)=0;
		virtual bool _dispatch(uint32_t uConnid, core::Sender& sdr)=0;
		virtual bool _dispatch(const std::string& strIp, uint16_t uPort, uint32_t uUri, const std::string& str)=0;
		virtual bool _dispatch(const std::string& strIp, uint16_t uPort, uint32_t uUri, sox::Marshallable& obj)=0;
	};
	// S2SÌåÏµ·¢°ü½Ó¿Ú(µ¥Ïß³Ì)
	class S2SRouter :
		public IS2SRouter,
		public Singleton<S2SRouter>
	{
	public:
		S2SRouter();
		virtual ~S2SRouter();

		virtual int flush(IConn *ansConn = NULL)
		{
			return 0;
		}

		virtual std::string GetFrom();
		virtual void SetFrom(const std::string &f);

	protected:
		// ÄÚ²¿Ñ¹°üº¯Êý£¬¶àÏß³ÌÄ£Ê½ÏÂÔÊÐíoverride
		virtual bool _dispatch(int64_t serverId, uint32_t uri, const sox::Marshallable &obj);
		virtual bool _dispatch(int64_t serverId, uint32_t uri, const std::string& str);
		virtual bool _dispatch(uint32_t uConnid, uint32_t uri, const sox::Marshallable &obj);
		virtual bool _dispatch(int64_t serverId, core::Sender& sdr);
		virtual bool _dispatch(uint32_t uConnid, core::Sender& sdr);
		virtual bool _dispatch(const std::string& strIp, uint16_t uPort, uint32_t uUri, const std::string& str);
		virtual bool _dispatch(const std::string& strIp, uint16_t uPort, uint32_t uUri, sox::Marshallable& obj);

	private:
		std::string tmpFrom;
	};

	class S2SRouterAware
	{
	public:
		S2SRouterAware() : router(0)
		{
		}

		void SetS2SRouter(S2SRouter* r)
		{
			router = r;
		}

		S2SRouter* GetS2SRouter()
		{
			return router;
		}
		
	protected:
		S2SRouter* router;
	};

	// ¶àÏß³Ì·¢°ü
	struct AsyncPacket
	{
		AsyncPacket(int64_t s, core::Sender* p)
			: serverId(s), pkt(p)
		{
		}

		int64_t serverId;
		core::Sender* pkt;
	};

	// ¶àÏß³Ì·¢°ü,¸ù¾ÝÁ¬½Ó·¢ËÍ.
	struct AsyncConnidPacket
	{
		AsyncConnidPacket(uint32_t uConnectid, core::Sender* p) : 
			uConnid(uConnectid), 
			pkt(p)
		{}

		uint32_t uConnid;
		core::Sender* pkt;
	};

	// Ïß³Ì·¢°ü,¸ù¾ÝIp:Port·¢ËÍ.
	struct AsyncIpPortPacket
	{
        
		AsyncIpPortPacket(const std::string& ip, uint16_t port, core::Sender* p):
			strIp(ip), port(port), pkt(p)
		{
		}
		std::string strIp;
		uint16_t port;
		core::Sender* pkt;
	};

	class ThreadRouter : public IS2SDispatcherAware
	{
	public:
		ThreadRouter();
		~ThreadRouter();

		void AddToQueue(int64_t serverId, core::Sender* p);
		void AddToQueue(uint32_t uConnid, core::Sender* p);
		void AddToQueue(const std::string& ip, uint16_t port, core::Sender* p);
		void Flush();

		std::string GetFrom();
		void SetFrom(const std::string &f);

	private:
		boost::mutex m_lstLock;
		std::list<AsyncPacket> m_lstPackets;

		boost::mutex m_connidlstLock;
		std::list<AsyncConnidPacket> m_lstConnidPackets;

		boost::mutex m_ipPortlstLock;
		std::list<AsyncIpPortPacket> m_lstIpPortPackets;

		std::string tmpFrom;
	};

	class S2SAsyncRouter :
		public IS2SRouter,
		public core::ILinkHandler, 
		public Singleton<S2SAsyncRouter>
	{
	public:
		S2SAsyncRouter();
		virtual ~S2SAsyncRouter();

		virtual int flush(core::IConn *ansConn = NULL);
		virtual int onData(const char*, size_t, IConn *conn, int type = 0);
		virtual void setPackLimit(uint32_t sz) {}

		virtual std::string GetFrom();
		virtual void SetFrom(const std::string &f);

	protected:
		virtual bool _dispatch(int64_t serverId, uint32_t uri, const sox::Marshallable &obj);
		virtual bool _dispatch(int64_t serverId, uint32_t uri, const std::string& str);
		virtual bool _dispatch(uint32_t uConnid, uint32_t uri, const sox::Marshallable &obj);
		virtual bool _dispatch(int64_t serverId, core::Sender& sdr);
		virtual bool _dispatch(uint32_t uConnid, core::Sender& sdr);
		virtual bool _dispatch(const std::string& strIp, uint16_t uPort, uint32_t uUri, const std::string& str);
		virtual bool _dispatch(const std::string& strIp, uint16_t uPort, uint32_t uUri, sox::Marshallable& obj);

	private:
		void __sendAll();

		void __sendAllFromTimer();
		ThreadRouter* __getThreadRoute();

	private:
		int 		 m_fd;
		s2sPipeConn* m_pipeConn;

		boost::thread_specific_ptr<ThreadRouter> ptr;

		// all writers
		std::vector<ThreadRouter *> routes;
		boost::mutex route_mux;

		// ¶¨ÆÚflush
		CAutoTimer m_flushTimer;
		bool m_bFlushFlag;
	};
}
