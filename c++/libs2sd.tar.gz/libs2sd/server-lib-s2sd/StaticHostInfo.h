#pragma once

#include "s2sPublic.h"

namespace core {
namespace s2sd {

typedef  std::map<ISPType, uint32_t>    ISP2IP_map_t;

class StaticHostInfo
{
public:
   StaticHostInfo();
  ~StaticHostInfo();

  bool load(const char *file);
  void parseData(std::string &data);
  void parseIsp2ip(std::string &str);
  std::string searchAttribute(std::string &data, const char *str);

  uint32_t getStatus();
  uint32_t getAera();
  uint32_t getCityId();
  uint32_t getServerId();
  uint32_t getSecGroupId();
  uint32_t getPriGroupId();
  uint32_t getIdcId();
  uint32_t getRoomId();

  std::string getDnips();
  std::string getGuid();
  std::string getRoom();
  std::string getDept();

  ISP2IP_map_t getIsp2Ip();
  bool isSmallIsp();
  void getIsp(std::set<ISPType>& ispSet);

  // console
  bool reLoad();
  std::string dumpMyInformation();

private:
  uint32_t        m_status;
  uint32_t        m_area;
  uint32_t        m_cityId;
  uint32_t        m_serverId;
  uint32_t        m_secGroupId;
  uint32_t        m_priGroupId;
  uint32_t        m_idcId;
  uint32_t        m_roomId;
  std::string     m_dnips;
  std::string     m_gUid;
  std::string     m_room;
  std::string     m_dept;
  ISP2IP_map_t    m_isp2Ip;
};

}
}