#pragma once

#include "server_common/server-lib/uuid.h"
#include "s2sPublic.h"
#include "s2sClientIf.h"

namespace core
{
	class IS2SServer
	{
	public:
		IS2SServer(): m_uSrvId(NONE_SERVER_ID64), m_uGrpId(NONE_SERVER_ID){}

		virtual ~IS2SServer() {}
		virtual bool startSV() = 0;

		virtual void setS2sNameKey(const std::string & name, const std::string& key)
		{
			setName(name);
			m_s2sKey = key;
		}
		virtual std::string getS2sKey() const
		{
			return m_s2sKey;
		}
		virtual void setName(const std::string& strName)
		{
			m_strName = strName;
			char buf[512];
			snprintf(buf, sizeof(buf), "%s/%ju", m_strName.c_str(), m_uSrvId);
			m_strStaticFullName = buf;
		}
		virtual std::string getName() const
		{
			return m_strName;
		}

		virtual void setServerId(int64_t uSrvId)
		{
			m_uSrvId = uSrvId;
			char buf[512];
			snprintf(buf, sizeof(buf), "%s/%ju", m_strName.c_str(), m_uSrvId);
			m_strStaticFullName = buf;
		}
		virtual int64_t getServerId() const
		{
			return m_uSrvId;
		}

		virtual void setGroupId(uint32_t uGrpId)
		{
			m_uGrpId = uGrpId;
		}
		virtual uint32_t getGroupId() const
		{
			return m_uGrpId;
		}

		virtual void setIp(const std::map<S2S::ISPType, uint32_t> & ips)
		{
			m_mapIspToIp = ips;
		}
		virtual void setIpByIsp(S2S::ISPType isp, const std::string & ip)
		{
		  if(!ip.empty())
			  m_mapIspToIp[isp] = sox::aton_addr(ip);
		}
		virtual bool getIpByIsp(S2S::ISPType isp, std::string & ip) const
		{
		  std::map<S2S::ISPType, uint32_t>::const_iterator it = m_mapIspToIp.find(isp);
			if(it != m_mapIspToIp.end())
			{
				ip = sox::addr_ntoa(it->second);
				return true;
			}
			ip = "";
			return false;
		}
		virtual std::map<S2S::ISPType, uint32_t> getIps() const
		{
			return m_mapIspToIp;
		}
		virtual void setUuid(const core::MUUID& uuid)
		{
			m_uuid = uuid;
		}
		virtual core::MUUID getUuid() const
		{
			return m_uuid;
		}

		virtual uint16_t getPort() = 0;
		virtual std::vector<uint16_t> getPorts() = 0;
		virtual void getFullName(std::string& fullName)
		{
			volatile int64_t uServerId = m_uSrvId;
			if (uServerId == NONE_SERVER_ID64)
			{
				return;
			}

			char buf[512];
			snprintf(buf, sizeof(buf), "%s/%ju", m_strName.c_str(), m_uSrvId);
			fullName = buf;
		}

		virtual const std::string & getFullName()
		{
			return m_strStaticFullName;
		}

	protected:
		// 进程的Daemon名字
		std::string m_strName;
		std::string m_s2sKey;

		// 进程的ServerId
		int64_t m_uSrvId;

		uint32_t m_uGrpId;
		std::map<S2S::ISPType, uint32_t> m_mapIspToIp;

		core::MUUID m_uuid;
		std::string m_strStaticFullName;
	};

	class IS2SServerAware
	{
	public:
		virtual ~IS2SServerAware() {}
		void SetS2SServer(IS2SServer* s)
		{
			server = s;
		}

		IS2SServer* GetS2SServer() const
		{
			return server;
		}

	protected:
		IS2SServer* server;
	};

}
