#pragma once

#include "core/sox/logger.h"
#include "core/sox/sockethelper.h"
#include "core/sox/tcpsock.h"
#include "core/sox/util.h"
#include "core/sox/snox.h"
#include "core/sox/singleton2.h"
#include "core/corelib/AbstractConn.h"
#include "core/corelib/InnerConn.h"
#include "core/sender.h"
#include "core/request.h"
#include "core/ilink.h"
#include "core/iserver.h"
#include "core/ibase.h"
#include "core/form.h"
#include "common/protocol/const.h"
#include "common/int_types.h"
#include "common/packet.h"

#define S2SDLOG(level, fmt, ...)  \
    log(level, "[s2sd::%s::%d::%s]: " fmt, __FILE__, __LINE__, __FUNCTION__, ##__VA_ARGS__)
