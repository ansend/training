#pragma once

#include "s2sPublic.h"
#include "is2sClient.h"
#include "s2sRouter.h"
#include "s2sRWLock.h"

#define BOOST_MULTI_INDEX_DISABLE_SERIALIZATION
#include "boost/multi_index_container.hpp"
#include "boost/multi_index/member.hpp"
#include "boost/multi_index/ordered_index.hpp"
#include "boost/multi_index/hashed_index.hpp"
#include "boost/multi_index/composite_key.hpp"

namespace core
{
namespace s2sd{
	namespace bmi = boost::multi_index;

	class CS2SServerFunc
	{
	public:
		// 获取服务器所在机房类型
		static uint32_t GetNetType(uint32_t dip, uint32_t wip)
		{
			uint32_t type;
			if (0 == dip) dip = 0xFFFFFFFF;
			if (0 == wip) wip = 0xFFFFFFFF;
			if (dip == 0xFFFFFFFF && wip != 0xFFFFFFFF)
			{
				type = CNC;
			}
			else if (dip != 0xFFFFFFFF && wip == 0xFFFFFFFF)
			{
				type = CTL;
			}
			else if (dip != 0xFFFFFFFF && wip != 0xFFFFFFFF)
			{
				type = CNC | CTL;
			}
			else
			{
				type = 0;
			}

			return type;
		}
		static uint32_t GetNetType(const std::map<S2S::ISPType, uint32_t> & ips)
		{
			// S2S::ISPType is the same as protocol::ISPType
			uint32_t type = 0;
			for(std::map<S2S::ISPType, uint32_t>::const_iterator it = ips.begin();
				it != ips.end(); ++it)
			{
				type |= it->first;
			}

			return type;
		}
		
		static bool GetBestPeerIp(std::pair<S2S::ISPType, uint32_t> & result,
			const std::map<S2S::ISPType, uint32_t> & myIps, 
			const std::map<S2S::ISPType, uint32_t> & peerIps)
		{
			std::map<S2S::ISPType, uint32_t>::const_iterator itRes = peerIps.begin();
			for(std::map<S2S::ISPType, uint32_t>::const_iterator itPeer = peerIps.begin();
				itPeer != peerIps.end(); ++itPeer)
			{
				S2S::ISPType type = itPeer->first;
				std::map<S2S::ISPType, uint32_t>::const_iterator itMine = myIps.find(type);
				if(itMine != myIps.end())
				{
					itRes = itPeer;
					break;
				}
			}

			if(itRes != peerIps.end())
			{
				result = *itRes;
				return true;
			}
			return false;
		}
		
		static std::string GetBestPeerIp(const std::map<S2S::ISPType, uint32_t> & myIps, const std::map<S2S::ISPType, uint32_t> & peerIps)
		{
			std::string strIp;
			std::pair<S2S::ISPType, uint32_t> result;
			if(GetBestPeerIp(result, myIps, peerIps))
			{
				strIp = sox::addr_ntoa(result.second);
			}
			return strIp;
		}
	};

	struct IpType{
		int ip;
		ISPType type;
		bool operator == (const IpType &r) const{
			return ip == r.ip;
		}
	};

	struct IpPortInfo{
		std::vector<IpType> ips;
		int port;
	};

	struct IpPortInfoCmp: public IpPortInfo{
		bool operator < (const IpPortInfoCmp &right) const{
			size_t lsz = ips.size();
			size_t rsz = right.ips.size();

			if(lsz < rsz){
				return true;
			}else if(lsz > rsz){
				return false;
			}else/* == */{
				for(size_t i = 0; i < lsz; ++i){
					if(ips[i].ip < right.ips[i].ip){
						return true;
					}else if(ips[i].ip > right.ips[i].ip){
						return false;
					}
				}
				return port < right.port;
			}
		}

		void addIp(int ip, ISPType isp){
			IpType pt;
			pt.ip = ip;
			pt.type = isp;
			addIp(pt);
		}

		void addIp(const IpType& pt){
			for(std::vector<IpType>::iterator it = ips.begin(); it != ips.end(); ++it){
				if(it->ip > pt.ip){
					ips.insert(it, pt);
					return;
				}
			}
			ips.push_back(pt);
		}

		void setPort(int p){
			port = p;
		}
	};

  inline IpPortInfoCmp constructInfo(const std::map<S2S::ISPType, uint32_t> & ips, uint16_t port){
    IpPortInfoCmp pp;
    pp.setPort(port);

    // S2S::ISPType is the same as protocol::ISPType
    for(std::map<S2S::ISPType, uint32_t>::const_iterator it = ips.begin();
      it != ips.end(); ++it)
    {
      pp.addIp(it->second, (ISPType)it->first);
    }
    return pp;
  }

  inline std::string dumpIps(const std::map<S2S::ISPType, uint32_t> & ips)
  {
    std::ostringstream os;
    for(std::map<S2S::ISPType, uint32_t>::const_iterator it = ips.begin();
      it != ips.end(); ++it)
    {
      os << it->first << "@" << sox::addr_ntoa(it->second) << ",";
    }
    return os.str();
  }

	// 服务器信息：
	struct CS2SServerBase
	{
		std::string m_sstr;
		int64_t m_serverId;
		uint32_t m_netType;
        uint32_t m_groupId;
        uint32_t m_uMainIP;//set as DIP if applicable, WIP otherwise
		IpPortInfoCmp m_address;

		CS2SServerBase()
            : m_sstr(""), m_serverId(NONE_SERVER_ID64), m_netType(-1), m_groupId(0), m_uMainIP(0)
		{
		}

		CS2SServerBase(std::string name, int64_t srvId, uint32_t netType, uint32_t groupId, uint32_t ip, IpPortInfoCmp& addr)
            : m_sstr(name), m_serverId(srvId), m_netType(netType), m_groupId(groupId), m_uMainIP(ip), m_address(addr)
		{
		}
	};

	// tags
	struct SvrInfo_Name{};
	struct SvrInfo_ServerId{};
	struct SvrInfo_NetTypeName{};
	struct SvrInfo_GroupIdName{};
	struct SvrInfo_IPName{};

	typedef bmi::multi_index_container<
		CS2SServerBase,
		bmi::indexed_by<
		// Indexed by ServerId
		bmi::ordered_unique<bmi::tag<SvrInfo_ServerId>, BOOST_MULTI_INDEX_MEMBER(CS2SServerBase,int64_t,m_serverId)>,
		// Indexed by name
		bmi::hashed_non_unique<bmi::tag<SvrInfo_Name>, BOOST_MULTI_INDEX_MEMBER(CS2SServerBase,std::string,m_sstr)>,
		// Indexed by Net
		//bmi::hashed_non_unique<bmi::tag<SvrInfo_NetType>, BOOST_MULTI_INDEX_MEMBER(CIMServer,uint32_t,m_netType)>,
		bmi::ordered_non_unique<bmi::tag<SvrInfo_NetTypeName>,
			bmi::composite_key<
			CS2SServerBase,
			BOOST_MULTI_INDEX_MEMBER(CS2SServerBase, uint32_t, m_netType),
			BOOST_MULTI_INDEX_MEMBER(CS2SServerBase, std::string, m_sstr)
			> >,
		// Indexed by GroupId
		//bmi::hashed_non_unique<bmi::tag<SvrInfo_GroupId>, BOOST_MULTI_INDEX_MEMBER(CIMServer,uint32_t,m_groupId)>,
		bmi::ordered_non_unique<bmi::tag<SvrInfo_GroupIdName>,
			bmi::composite_key<
			CS2SServerBase,
			BOOST_MULTI_INDEX_MEMBER(CS2SServerBase, uint32_t, m_groupId),
			BOOST_MULTI_INDEX_MEMBER(CS2SServerBase, std::string, m_sstr)
			> >,
		// Indexed by IP.
		//bmi::ordered_non_unique<bmi::tag<SvrInfo_IP>,BOOST_MULTI_INDEX_MEMBER(CIMServer,uint32_t,m_uMainIP)>
		//bmi::ordered_non_unique<bmi::tag<SvrInfo_IPName>,
		bmi::hashed_non_unique<bmi::tag<SvrInfo_IPName>, //for performance
			bmi::composite_key<
			CS2SServerBase,
			BOOST_MULTI_INDEX_MEMBER(CS2SServerBase, uint32_t, m_uMainIP),
			BOOST_MULTI_INDEX_MEMBER(CS2SServerBase, std::string, m_sstr)
			> >
		>
	> S2SvrInfo_t;

	typedef S2SvrInfo_t::index<SvrInfo_ServerId>::type		S2SSvrInfoByServerId_t;
	typedef S2SvrInfo_t::index<SvrInfo_Name>::type			S2SSvrInfoByName_t;
	//typedef S2SvrInfo_t::index<SvrInfo_IP>::type			IMSvrInfoByIP_t;
	//typedef S2SvrInfo_t::index<SvrInfo_NetType>::type		IMSvrInfoByNetType_t;
	typedef S2SvrInfo_t::index<SvrInfo_NetTypeName>::type	S2SSvrInfoByNetTypeName_t;
	typedef S2SvrInfo_t::index<SvrInfo_GroupIdName>::type	S2SSvrInfoByGroupName_t;
	typedef S2SvrInfo_t::index<SvrInfo_IPName>::type		S2SSvrInfoByIPName_t;


	// 保存服务器信息的容器
	class CS2SServersContainer
	{
	public:
		//typedef std::map<uint32_t, S2SvrInfo_t> ServersMap_T;
		typedef S2SvrInfo_t ServersMap_T;

		void AddServer(const CS2SServerBase& srv);

		void RemoveServer(const int64_t srvId);

		void ClearServer();

		// 根据服务器类型，获取服务器ID
		void GetServersByName(const std::string& name, std::vector<int64_t>& vecIDs);

		// 根据服务器类型和网络类型，获取服务器ID
		void GetServersByNameType(const std::string& name, const uint32_t type, std::vector<int64_t>& vecIDs);

		// 根据服务器类型和网络类型，获取服务器ID（匹配网络类型的时候，包含双线服务器）
		void GetServersByNameTypeEx(const std::string& name, const uint32_t type, std::vector<int64_t>& vecIDs);

		// 根据服务器类型和网络类型, 不同的groupid，获取服务器ID
		void GetServersByNameTypeOtherGroup(const std::string& name, uint32_t type, uint32_t group, std::vector<int64_t>& vecIDs);

        void GetServersByNameGroup(const std::string& name, uint32_t group, std::vector<int64_t>& vecIDs);

		void GetServersByNameIP(const std::string& name, uint32_t ip, std::vector<int64_t>& vecIDs);

		CS2SServerBase GetServerByID(const int64_t serverID);

		std::string DumpAll(const std::string& name);

		bool SuppressLog(bool bFlag = true);
	private:
		// 处于RUNNING态的所有服务器
		ServersMap_T m_mapServers;
		bool m_bSuppressLog;
	};

	class ICS2SServersInfo : public core::IS2SServerAware,
		public core::IS2SClientAwareW
	{
	public:
		ICS2SServersInfo()
		{
			srand(time(NULL));
		}

		virtual ~ICS2SServersInfo(){	}

		// 通过服务器类型名和网络类型，获取相同网络下同一类型的所有服务器ID
		// 注意： 包含自己
		virtual std::vector<int64_t> GetServersIDByNameType(const std::string& name, const uint32_t type) = 0;

		// 匹配网络类型时，包含双线
		virtual std::vector<int64_t> GetServersIDByNameTypeEx(const std::string& name, const uint32_t type) = 0;

		// 通过服务器类型名，获取一类型的所有服务器ID
		// 注意： 包含自己
		virtual std::vector<int64_t> GetServersIDByName(const std::string& name) = 0;

		// 通过服务器名和网络类型，随机获取一个服务器ID
		//   成功返回：id
		//   失败返回：-1
		// 注意： 包含自己
		virtual int64_t RandomServerIDByNameType(const std::string& name, const uint32_t type) = 0;

		// 匹配网络类型时，包含双线
		virtual int64_t RandomServerIDByNameTypeEx(const std::string& name, const uint32_t type) = 0;

		// 通过服务器名和网络类型，不同的group，随机获取一个服务器ID
		virtual int64_t RandomServerIDByNameTypeOtherGroup(const std::string& name, uint32_t type, uint32_t group) = 0;

		// 通过服务器名，随机获取一个服务器ID
		//   成功返回：id
		//   失败返回：-1
		// 注意： 包含自己
		virtual int64_t RandomServerIDByName(const std::string& name) = 0;

		// 获取网络类型
		virtual uint32_t GetNetTypeByID(const int64_t serverID) = 0;

		virtual uint32_t GetMyNetType() = 0;

		// 获取groupid
		virtual uint32_t GetGroupIdBySid(const int64_t serverID) = 0;

		// 判断两个服务器是否相同网络类型
		virtual bool IsSameNetType(const int64_t srvId1, const int64_t srvId2) = 0;

		virtual std::vector<int64_t> GetServersByNameGroup(const std::string& name, uint32_t group) = 0;

		virtual int64_t RandomServerIDByNameGroup(const std::string& name, uint32_t group) = 0;

		virtual int64_t RandomServerIDByNameIP(const std::string& name, uint32_t ip = 0) = 0;

		virtual void SetMyServerID(const int64_t uServerID) = 0;
		virtual bool IsServerIDExist(const int64_t uServerId) = 0;

		//virtual void AddCareName(const std::string& strName) = 0;

		virtual bool SuppressContainerLog(bool bFlag = true) = 0;
		virtual std::string DumpAll(const std::string& name) = 0;
	};

	//建议用Instance
	class ICS2SServersInfoAware
	{
	protected:
		ICS2SServersInfo *m_pS2SSrvInfo;
	public:
		virtual ~ICS2SServersInfoAware() {}
		virtual void SetS2SServerInfoHelper(ICS2SServersInfo *obj)
		{
			m_pS2SSrvInfo = obj;
		}
	};


///////////////////////////////// 单线程环境服务器信息容器实现 ////////////////////////////////

	class CS2SServersInfo : public ICS2SServersInfo, public Singleton<CS2SServersInfo>
	{
	public:
		CS2SServersInfo() : m_uMyMainIP(uint32_t(-1)), m_uMyServerId(-1), m_uMyNetType(uint32_t(-1))
		{}

		virtual ~CS2SServersInfo() {}

		// 通过服务器类型名和网络类型，获取相同网络下同一类型的所有服务器ID
		virtual std::vector<int64_t> GetServersIDByNameType(const std::string& name, const uint32_t type);

		virtual std::vector<int64_t> GetServersIDByNameTypeEx(const std::string& name, const uint32_t type);

		// 通过服务器类型名，获取一类型的所有服务器ID
		virtual std::vector<int64_t> GetServersIDByName(const std::string& name);

		// 通过服务器名和网络类型，随即获取一个服务器ID
		virtual int64_t RandomServerIDByNameType(const std::string& name, const uint32_t type);

		virtual int64_t RandomServerIDByNameTypeEx(const std::string& name, const uint32_t type);

		virtual int64_t RandomServerIDByNameTypeOtherGroup(const std::string& name, uint32_t type, uint32_t group);

		// 通过服务器名，随即获取一个服务器ID
		virtual int64_t RandomServerIDByName(const std::string& name);

		// 获取网络类型
		virtual uint32_t GetNetTypeByID(const int64_t serverID);

		virtual uint32_t GetMyNetType();

    	virtual uint32_t GetMyMainIp();

		// 获取groupid
		virtual uint32_t GetGroupIdBySid(const int64_t serverID);

		// 判断两个服务器是否相同网络类型
		virtual bool IsSameNetType(const int64_t srvId1, const int64_t srvId2);


		virtual std::vector<int64_t> GetServersByNameGroup(const std::string& name, uint32_t group);

		virtual int64_t RandomServerIDByNameGroup(const std::string& name, uint32_t group);

		virtual int64_t RandomServerIDByNameIP(const std::string& name, uint32_t ip = 0);

		virtual void SetMyServerID(const int64_t uServerID);
		virtual bool IsServerIDExist(const int64_t uServerId);

		//virtual void AddCareName(const std::string& strName);

		virtual bool SuppressContainerLog(bool bFlag = true);

		virtual std::string DumpAll(const std::string& name);

	public:

		virtual void onServerRemoved(const S2sMeta& info);
		virtual void onServerAdd(const S2sMeta& info);

		// 进程第一次启动后拉取全部视图， 触发
		// 另：当本地缓存与服务器视图相比比较旧的时候， 也会触发
		virtual void onServerRefresh();

	protected:
		CS2SServersContainer m_srvContainer;
		uint32_t m_uMyMainIP;
		int64_t m_uMyServerId;
		uint32_t m_uMyNetType;
		//SetNames_t m_setCareNames;
	};

	class CS2SServersInfoMT : public ICS2SServersInfo, public Singleton<CS2SServersInfoMT>
	{
	public:
		CS2SServersInfoMT() : m_uMyMainIP(uint32_t(-1)), m_uMyServerId(-1), m_uMyNetType(uint32_t(-1))
		{}

		virtual ~CS2SServersInfoMT() {}

		// 通过服务器类型名和网络类型，获取相同网络下同一类型的所有服务器ID
		virtual std::vector<int64_t> GetServersIDByNameType(const std::string& name, const uint32_t type);

		virtual std::vector<int64_t> GetServersIDByNameTypeEx(const std::string& name, const uint32_t type);

		// 通过服务器类型名，获取一类型的所有服务器ID
		virtual std::vector<int64_t> GetServersIDByName(const std::string& name);

		// 通过服务器名和网络类型，随即获取一个服务器ID
		virtual int64_t RandomServerIDByNameType(const std::string& name, const uint32_t type);

		virtual int64_t RandomServerIDByNameTypeEx(const std::string& name, const uint32_t type);

		virtual int64_t RandomServerIDByNameTypeOtherGroup(const std::string& name, uint32_t type, uint32_t group);

		// 通过服务器名，随即获取一个服务器ID
		virtual int64_t RandomServerIDByName(const std::string& name);

		// 获取网络类型
		virtual uint32_t GetNetTypeByID(const int64_t serverID);

		virtual uint32_t GetMyNetType();

    	virtual uint32_t GetMyMainIp();

		// 获取groupid
		virtual uint32_t GetGroupIdBySid(const int64_t serverID);

		// 判断两个服务器是否相同网络类型
		virtual bool IsSameNetType(const int64_t srvId1, const int64_t srvId2);


		virtual std::vector<int64_t> GetServersByNameGroup(const std::string& name, uint32_t group);

		virtual int64_t RandomServerIDByNameGroup(const std::string& name, uint32_t group);

		virtual int64_t RandomServerIDByNameIP(const std::string& name, uint32_t ip = 0);

		virtual void SetMyServerID(const int64_t uServerID);
		virtual bool IsServerIDExist(const int64_t uServerId);

		//virtual void AddCareName(const std::string& strName);

		virtual bool SuppressContainerLog(bool bFlag = true);

		virtual std::string DumpAll(const std::string& name);
	public:

		virtual void onServerRemoved(const S2sMeta& info);
		virtual void onServerAdd(const S2sMeta& info);

		// 进程第一次启动后拉取全部视图， 触发
		// 另：当本地缓存与服务器视图相比比较旧的时候， 也会触发
		virtual void onServerRefresh();

	protected:
		CRWLockMutex m_mutexRWLock;
		CS2SServersContainer m_srvContainer;
		uint32_t m_uMyMainIP;
		int64_t m_uMyServerId;
		uint32_t m_uMyNetType;
		//SetNames_t m_setCareNames;
	};
}
}

//single thread
#define INIT_S2S_SERVER_INFO_INSTANCE \
	core::s2sd::CS2SServersInfo* __s2sserverInfo = core::s2sd::CS2SServersInfo::Instance();\
	__s2sserverInfo->setS2SClient(&__s2sClient);\
	__s2sserverInfo->SetS2SServer(&__s2sServer);\
	__s2sserverInfo->SuppressContainerLog(false);
