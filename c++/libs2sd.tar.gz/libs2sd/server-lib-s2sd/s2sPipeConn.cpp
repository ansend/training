#include "s2sPipeConn.h"

using namespace core;

s2sPipeConn::s2sPipeConn()
{
}

s2sPipeConn::~s2sPipeConn()
{
  select(sox::SEL_READ, 0);
}

void s2sPipeConn::handle(int ev)
{
  if (socket().isConnected())
  {
	switch (ev)
    {
  		case sox::SEL_READ:
      {
  			onRead();
  			return;
  		}
  		case sox::SEL_WRITE:
  		case sox::SEL_TIMEOUT:
      {
        S2SDLOG(Warn, "Socket handle unwanted event");
  			return;
  		}
		}
	}
  else
  {
    S2SDLOG(Warn, "Socket not connected");
    return;
	}
}

void s2sPipeConn::onRead()
{
  if (m_pHandler != NULL)
  {
    m_pHandler->onData(NULL, 0, this, 2);
  }
}
bool s2sPipeConn::watch(int fd, core::ILinkHandler* handler)
{
  socket().attach(fd);
  socket().setblocking(false);
  select(sox::SEL_ALL, sox::SEL_READ);

  m_pHandler = handler;

  return true;
}

