#pragma once

#include "server_common/helper/TimerHandler.h"
#include "server_common/server-lib-s2sd/s2sRouteTarget.h"
#include "server_common/server-lib-s2sd/s2sPublic.h"

#include "PDemoInner.h"

class DemoContainer :
    public core::PHClass,
    public core::CS2SRouteTarget,
    public core::IDaemonServerAware
{
public:
    DemoContainer();
    virtual ~DemoContainer();
    bool init();

    DECLARE_FORM_MAP
    void OnPing(PPing * pReq, core::IConn* conn);
    void OnPong(PPong * pRes, core::IConn* conn);

    void OnTimeReq(PTimeReq * pReq, core::IConn* conn);
    void OnTimeRes(PTimeRes * pRes, core::IConn* conn);

    void OnStrRes(PStrRes * pRes);

private:
    bool Timer();
    TimerHandler<DemoContainer, &DemoContainer::Timer> m_timer;
};
