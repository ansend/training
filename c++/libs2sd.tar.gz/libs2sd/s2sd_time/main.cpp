
#include "DemoContainer.h"

#include "core/sox/snox.h"
#include "server_common/helper/main_inc.h"
#include "server_common/server-lib-s2sd/s2sdEnv.h"

using namespace core;
using namespace sox;

int main(int sz, char *args[])
{
    init_daemon dm(sz, args);
    WrapServerStart::init();

    CONFIG_RDAEMON_SERVER_INIT("daemon_time_d",
            BRouteAppContext, 
            MultiConnManagerImp,
            InnerConnCreator,
            InnerConnCreator, 
            BackLinkHandler, 
            RouteWriter,
            TinyXmlServerConfigImp);

    // 初始化libs2sd, 使用s2sName和s2sKey
    s2sd::init("s2sd_time_d", "22494cac3376b418be70f6548fd9d372", s2sd::S2SD_SINGLETHREAD);
    s2sd::getClient()->addNotifySuffix("s2sd_demo_d");

    // 业务自己的初始化
    DemoContainer app;
    app.init();
    app.setDaemonPointer(&__writer, &__clientDaemon);

    // 旧daemon部分
    app.setServer(&__server);
    // 旧daemon添加uri handler
    __appContext.addEntry(DemoContainer::getFormEntries(), &app, NULL);

    // 把业务自己的uri handler添加到s2sd
    // 一定来说是daemon框架定义了"DECLARE_FORM_MAP"的, 都应该添加进来
    s2sd::addUriEntries(&app);

    // 旧daemon start
    DAEMON_SERVER_START;
    // s2sd start
    s2sd::start();
    // daemon框架的epoll loop
    WrapServerStart::run();
    return 0;
}