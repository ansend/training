#include "DemoContainer.h"

#include "server_common/server-lib-s2sd/s2sdEnv.h"

using namespace core;

#define FUNLOG(level, fmt, ...)  \
    log(level, "[Demo::%s::%d::%s]: " fmt, __FILE__, __LINE__, __FUNCTION__, ##__VA_ARGS__)

BEGIN_FORM_MAP(DemoContainer)
    ON_LINK(PPing, &DemoContainer::OnPing)
    ON_LINK(PPong, &DemoContainer::OnPong)
    ON_LINK(PTimeReq, &DemoContainer::OnTimeReq)
    ON_LINK(PTimeRes, &DemoContainer::OnTimeRes)
    ON_REQUEST(PStrRes, &DemoContainer::OnStrRes)
END_FORM_MAP()

DemoContainer::DemoContainer()
{
}
DemoContainer::~DemoContainer()
{
}
bool DemoContainer::init()
{
    m_timer.init(this);
    m_timer.start(60 * 1000);

    return true;
}

void DemoContainer::OnPing(PPing * pReq, core::IConn* conn)
{
    PPong pong;
    pong.serverId = pReq->serverId;

    answer(pong.uri, RES_SUCCESS, pong);

    uint64_t uServerId = 0;
    std::string strFrom = GetFrom();
    s2sd::getSid(strFrom, uServerId);

    FUNLOG(Info, "recv ping from:%s-(%s)-%llu s2sd:%u serverId:%llx",
     s2sd::connpeer(conn).c_str(), strFrom.c_str(), uServerId, s2sd::isS2SOnHandle(), pong.serverId);
}
void DemoContainer::OnPong(PPong * pRes, core::IConn* conn)
{
    FUNLOG(Info, "recv pong from:%s", s2sd::connpeer(conn).c_str());
}

void DemoContainer::OnTimeReq(PTimeReq * pReq, core::IConn* conn)
{
    PTimeRes res;
    if (s2sd::isS2SOnHandle())
    {
        res.serverId = s2sd::getServer()->getServerId();
    }
    else
    {
        res.serverId = server->getServerId();
    }
    res.serverTs = sox::env::now;

    uint64_t uServerId = 0;
    std::string strFrom = GetFrom();
    s2sd::getSid(strFrom, uServerId);

    // s2sd::getRouter()->dispatch(conn->getConnId(), res.uri, res);    
    answer(res.uri, RES_SUCCESS, res);
    FUNLOG(Info, "recv time-req from:%s-(%s)-%llu -> id:%llx-%llu",
        s2sd::connpeer(conn).c_str(), strFrom.c_str(), uServerId, res.serverId, res.serverTs);
}
void DemoContainer::OnTimeRes(PTimeRes * pRes, core::IConn* conn)
{
    FUNLOG(Info, "recv time-res from:%s -> id:%llx-%llu",
        s2sd::connpeer(conn).c_str(), pRes->serverId, pRes->serverTs);
}
void DemoContainer::OnStrRes(PStrRes * pRes)
{
    // 对端如果不是用route/routeS, 则为0
    uint64_t uServerId = 0;
    std::string strFrom = GetFrom();
    s2sd::getSid(strFrom, uServerId);

    FUNLOG(Info, "from:(%s)-%llu recv strReq:(%s) strRes:(%s)",
    strFrom.c_str(), uServerId, pRes->strReq.c_str(), pRes->strRes.c_str());    
}

bool DemoContainer::Timer()
{
    FUNLOG(Info, "daemon myId:%x", server->getServerId());
    FUNLOG(Info, "s2sd myId:%llx", s2sd::getServer()->getServerId());

    char buf[512];
    ::snprintf(buf, sizeof(buf), "my daemonId:%x s2sId:%jx", server->getServerId(), s2sd::getServer()->getServerId());

    PStrReq obj;
    obj.strReq = buf;
    route("daemon_demo_d", obj.uri, obj);
    route("s2sd_demo_d", obj.uri, obj);
    return true;
}