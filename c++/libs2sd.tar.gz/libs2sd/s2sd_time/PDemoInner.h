#pragma once
#include "packet.h"

struct PPing : public sox::Marshallable
{
    enum { uri = 1000 };

    uint64_t serverId;
    virtual void marshal(sox::Pack &pk) const{
        pk << serverId;
    }
    virtual void unmarshal(const sox::Unpack &pk){
        pk >> serverId;
    }
};

struct PPong : public PPing
{
    enum { uri = 1001 };
};


struct PTimeReq : public sox::Marshallable
{
    enum { uri = 1002 };

    virtual void marshal(sox::Pack &pk) const 
    {
    }
    virtual void unmarshal(const sox::Unpack &up) 
    {
    }
};
struct PTimeRes : public sox::Marshallable
{
    enum { uri = 1003 };

    uint64_t serverId;
    uint64_t serverTs;
    virtual void marshal(sox::Pack &pk) const 
    {
        pk << serverId << serverTs;
    }
    virtual void unmarshal(const sox::Unpack &up) 
    {
        up >> serverId >> serverTs;
    }
};

struct PStrReq : public sox::Marshallable
{
    enum { uri = 1004 };
    std::string     strReq;

    virtual void marshal(sox::Pack &pk) const 
    {
        pk << strReq;
    }
    virtual void unmarshal(const sox::Unpack &up) 
    {
        up >> strReq;
    }
};
struct PStrRes : public sox::Marshallable
{
    enum { uri = 1005 };

    std::string     strReq;
    std::string     strRes;

    virtual void marshal(sox::Pack &pk) const 
    {
        pk << strReq << strRes;
    }
    virtual void unmarshal(const sox::Unpack &up) 
    {
        up >> strReq >> strRes;
    }
};


