#include "DemoContainer.h"

#include "server_common/server-lib-s2sd/s2sdEnv.h"

using namespace core;

#define FUNLOG(level, fmt, ...)  \
    log(level, "[Demo::%s::%d::%s]: " fmt, __FILE__, __LINE__, __FUNCTION__, ##__VA_ARGS__)

BEGIN_FORM_MAP(DemoContainer)
    ON_LINK(PPing, &DemoContainer::OnPing)
    ON_LINK(PPong, &DemoContainer::OnPong)
    ON_LINK(PTimeRes, &DemoContainer::OnTimeRes)
    ON_LINK(PStrReq, &DemoContainer::OnStrReq)
END_FORM_MAP()

DemoContainer::DemoContainer() : m_uTransId(0)
{
}
DemoContainer::~DemoContainer()
{
}
bool DemoContainer::init()
{
    m_timer.init(this);
    m_timer.start(20 * 1000);

    return true;
}

void DemoContainer::OnPing(PPing * pReq, core::IConn* conn)
{
    uint64_t myId = s2sd::getServer()->getServerId();
    if (myId != pReq->serverId)
    {
        FUNLOG(Warn, "ping server:%llx not mine:%llx", pReq->serverId, myId);
        return ;
    }
    PPong pong;
    pong.serverId = myId;

    s2sd::getRouter()->dispatch(conn->getConnId(), pong.uri, pong);
    FUNLOG(Info, "recv ping from:%s:", s2sd::connpeer(conn).c_str());
}
void DemoContainer::OnPong(PPong * pRes, core::IConn* conn)
{
    FUNLOG(Info, "recv pong from:%s", s2sd::connpeer(conn).c_str());
}

void DemoContainer::OnTimeRes(PTimeRes * pRes, core::IConn* conn)
{
    FUNLOG(Info, "recv time-res from:%s -> id:%llx-%llu",
        s2sd::connpeer(conn).c_str(), pRes->serverId, pRes->serverTs);
}
void DemoContainer::OnStrReq(PStrReq * pReq, core::IConn* conn)
{
    PStrRes res;
    res.strReq = pReq->strReq;
    res.strRes = "new-s2s";
    s2sd::getRouter()->dispatch(conn->getConnId(), res.uri, res);
    FUNLOG(Info, "recv strReq:%s", pReq->strReq.c_str());
}

bool DemoContainer::Timer()
{
    std::string strSvc = TIME_SERVICE;
    std::string strDump = s2sd::getS2sSvrInfo()->DumpAll(strSvc);    
    std::cout << strSvc << " info:" << strDump << std::endl;
    //FUNLOG(Info, "%s info:%s", strSvc.c_str(), strDump.c_str());

    {
        PPing ping;
        ping.serverId = s2sd::getServer()->getServerId();
        route(TIME_SERVICE, ping.uri, ping);
        FUNLOG(Info, "send ping to server:%s", TIME_SERVICE);
    }

    int64_t uServerId = s2sd::getS2sSvrInfo()->RandomServerIDByName(TIME_SERVICE);
    if (-1 != uServerId)
    {
        PTimeReq req;
        routeS(uServerId, req.uri, req);
        FUNLOG(Info, "send time-req to server:%llx", uServerId);
    }

    return true;
}