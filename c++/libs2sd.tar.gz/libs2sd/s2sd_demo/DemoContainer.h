#pragma once

#include "server_common/helper/TimerHandler.h"
#include "server_common/server-lib-s2sd/s2sPublic.h"
#include "server_common/server-lib-s2sd/s2sRouteTarget.h"

#include "PDemoInner.h"

#define TIME_SERVICE "s2sd_time_d"

class DemoContainer :
    public core::PHClass,
    public core::CS2SRouteTarget
{
public:
    DemoContainer();
    virtual ~DemoContainer();
    bool init();

    DECLARE_FORM_MAP
    
    void OnPing(PPing * pReq, core::IConn* conn);
    void OnPong(PPong * pRes, core::IConn* conn);
    void OnTimeRes(PTimeRes * pRes, core::IConn* conn);
    void OnStrReq(PStrReq * pReq, core::IConn* conn);

private:
    bool Timer();
    TimerHandler<DemoContainer, &DemoContainer::Timer> m_timer;

    uint64_t m_uTransId;
};
