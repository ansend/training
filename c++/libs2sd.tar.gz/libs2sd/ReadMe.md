## s2sd ##
- 使用旧daemon框架(core & server-lib)，注册到新节点发现s2s
- 接收消息的上抛，与原框架模式相同；发送消息的接口，可以独立使用s2s接口，也可以使用兼容旧daemon接口route/routeS
- 对于旧daemon框架的进程，迁移到s2sd时，改动最小化，只需要改动main初始化s2sd，以及发消息的继承类而已

## functions ##
* s2sdEnv.h

    初始化s2sd环境相关，以及环境接口，会自动获取机器的isp & ip & groupId，默认listen端口以40000开始递增

* is2sClient.h

    IS2SClient为s2s client相关接口，包含
        addNotifySuffix - 添加感兴趣server name
        addExtKey - 添加s2s data key <-> value
        getServer - 获取server info

    IS2SClientAware感兴趣server的观察者

* is2sServer.h

    IS2SServer为s2s server相关接口，包含
        getServerId - 获取自己server id

* s2sRouter.h

    各种发消息接口

* s2sSvrInfo.h

    获取各种server info

* 兼容

    s2sRouteTarget.h 兼容旧daemon server-lib/server-lib2的route/routeS接口
    s2sLib3Target.h 兼容旧daemon server-lib3/dblib的接口

## notice ##
- 按server name route消息时，建议s2s name和旧daemon name是不一样的，人为避免route区分不开造成错误路由
- 按server id routeS消息时，一定要添加s2sd库订阅，旧daemon会自动订阅全网节点，但是s2s只会订阅自己感兴趣的server，所以这里千万注意
- 同步回包时，建议使用answer按口，会自动判断是通过s2s链接还是旧daemon链接回包
- 异步回包时，使用routeS时千万注意，因为s2s只会订阅感兴趣的server，如果没有订阅请求者，通过server id会找不到对端context(ip & port等)
- 使用server-lib3时，注册s2sd::addUriEntries添加消息处理时，要先于旧daemon sf->getAppContext()->addEntry，因为后者会改变entry数组
- s2sd的route/routeS接口，为了保证和旧daemon兼容，有增加外层PRouter/PServerIdRouter协议包，使用s2sd::getSid替换旧daemon的DomainName::getSid，可以获取route端的server id

## 旧daemon迁移 ##
- 先迁移服务依赖项到s2sd上去，使它能同时处理旧daemon链接消息，以及通过s2s链接消息
- 再迁移当前服务到s2sd上去，使它通过s2s节点发现依赖项，并建立请求（可以简单做一个console动态开关）
- 再把依赖项服务的旧daemon注册部分去掉，再把当前服务的旧daemon注册部分去掉
- 一个进程具体工作：
    在main函数里面添加s2sd初始化，参考demo
    把旧route接口继承类替换为CS2SRouteTarget或CS2SLib3Target
    把旧有使用32bit server id替换为64bit server id (可同时兼容s2s和daemon server id)

## demo ##
- s2sd_daemon_demo —— 典型旧daemon进程demo，用于测试
- s2sd_demo —— 完全独立使用s2sd，只注册到s2s，用于测试
- s2sd_time —— 单线程，兼容旧server-lib和server-lib2，同时注册到s2s和旧daemon，可以同时处理s2s和旧daemon消息，发送消息自动差别新旧daemon路由
- s2sd_time_lib3 —— 多线程，兼容旧server-lib3和dblib，同时注册到s2s和旧daemon，可以同时处理s2s和旧daemon消息，发送消息自动差别新旧daemon路由

## author ##
    成杰 service组 chengjie@yy.com