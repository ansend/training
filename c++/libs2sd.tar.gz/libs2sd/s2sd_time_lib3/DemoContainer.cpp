#include "DemoContainer.h"

#include "server_common/server-lib-s2sd/s2sdEnv.h"

using namespace core;

#define FUNLOG(level, fmt, ...)  \
    log(level, "[Demo::%s::%d::%s]: " fmt, __FILE__, __LINE__, __FUNCTION__, ##__VA_ARGS__)

BEGIN_FORM_MAP(DemoContainer)
    ON_REQUEST(PPing, &DemoContainer::OnPing)
    ON_REQUEST(PPong, &DemoContainer::OnPong)
    ON_REQUEST(PTimeReq, &DemoContainer::OnTimeReq)
    ON_REQUEST(PTimeRes, &DemoContainer::OnTimeRes)
    ON_REQUEST(PStrRes, &DemoContainer::OnStrRes)
END_FORM_MAP()

DemoContainer::DemoContainer()
{
}
DemoContainer::~DemoContainer()
{
}
bool DemoContainer::init()
{
    m_timer.init(this);
    m_timer.start(60 * 1000);

    return true;
}

void DemoContainer::OnPing(PPing * pReq)
{
    PPong pong;
    pong.serverId = pReq->serverId;

    answer(pong.uri, RES_SUCCESS, pong);
    FUNLOG(Info, "recv ping serverId:%llx s2sd:%u", pong.serverId, s2sd::isS2SOnHandle());
}
void DemoContainer::OnPong(PPong * pRes)
{
    FUNLOG(Info, "recv pong s2sd:%u", s2sd::isS2SOnHandle());
}

void DemoContainer::OnTimeReq(PTimeReq * pReq)
{
    PTimeRes res;
    if (s2sd::isS2SOnHandle())
    {
        res.serverId = s2sd::getServer()->getServerId();
    }
    else
    {
        res.serverId = server->getServerId();
    }
    res.serverTs = sox::env::now;

    answer(res.uri, RES_SUCCESS, res);
    FUNLOG(Info, "recv time-req id:%llx-%llu s2sd:%u", res.serverId, res.serverTs, s2sd::isS2SOnHandle());
}
void DemoContainer::OnTimeRes(PTimeRes * pRes)
{
    FUNLOG(Info, "recv time-res id:%llx-%llu s2sd:%u", pRes->serverId, pRes->serverTs, s2sd::isS2SOnHandle());
}
void DemoContainer::OnStrRes(PStrRes * pRes)
{
    FUNLOG(Info, "recv strReq:(%s) strRes:(%s)", pRes->strReq.c_str(), pRes->strRes.c_str());    
}

bool DemoContainer::Timer()
{
    FUNLOG(Info, "daemon myId:%x", server->getServerId());
    FUNLOG(Info, "s2sd myId:%llx", s2sd::getServer()->getServerId());

    std::vector<uint32_t> vecTmp = serverFacade->getServerView()->getValidServers("daemon_demo_d");
    std::ostringstream ossId;
    std::copy(vecTmp.begin(), vecTmp.end(), std::ostream_iterator<uint32_t>(ossId, "/"));
    FUNLOG(Info, "daemon_demo_d serverId:%s", ossId.str().c_str());

    char buf[512];
    ::snprintf(buf, sizeof(buf), "my daemonId:%x s2sId:%jx", server->getServerId(), s2sd::getServer()->getServerId());

    PStrReq obj;
    obj.strReq = buf;

    dispatchByGroupName("daemon_demo_d", 337, obj.uri, obj);
    dispatchByGroupName("s2sd_demo_d", 337, obj.uri, obj);

    return true;
}