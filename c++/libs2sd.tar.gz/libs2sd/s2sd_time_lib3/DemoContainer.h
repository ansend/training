#pragma once

#include "server_common/server-lib3/IServerStategy.h"
#include "server_common/server-lib3/interface.h"
#include "server_common/server-lib3/TMTInstanceFactory.h"
#include "server_common/server-lib3/MTLinkHandler.h"
#include "server_common/server-lib3/SimpleProxyServer.h"
#include "server_common/server-lib3/ProxyDaoProcessor.h"
#include "server_common/server-lib3/DaemonClient3.h"
#include "server_common/server-lib3/DaoNameHelper.h"
#include "server_common/server-lib3/RouteRequestProcessor.h"

#include "server_common/server-lib-s2sd/s2sLib3Target.h"
#include "server_common/server-lib-s2sd/s2sPublic.h"

#include "PDemoInner.h"

class DemoContainer :
    public core::PHClass,
    public core::CS2SLib3Target, // 替换 InstanceTarget 和 IGroupNameDispatcherAware
    public core::IInstanceFactory,
    public core::IDaemonServerAware,
    public core::IServerFacadeAware
{
public:
    DemoContainer();
    virtual ~DemoContainer();
    bool init();

    // from IInstanceFactory
    virtual core::PHClass* getInstance(core::Request& request, core::IConn* conn, core::InstanceTarget** out) 
    {
        *out = this;
        return this;
    };

    DECLARE_FORM_MAP
    void OnPing(PPing * pReq);
    void OnPong(PPong * pRes);

    void OnTimeReq(PTimeReq * pReq);
    void OnTimeRes(PTimeRes * pRes);

    void OnStrRes(PStrRes * pRes);

private:
    bool Timer();
    TimerHandler<DemoContainer, &DemoContainer::Timer> m_timer;
};
