
#include "DemoContainer.h"

#include "core/sox/snox.h"
#include "core/corelib/WrapServerStart.h"
#include "server_common/helper/unixdaemon.h"
#include "server_common/server-lib-s2sd/s2sdEnv.h"

using namespace core;
using namespace sox;

int main(int sz, char *args[])
{
    init_daemon dm(sz, args);
    WrapServerStart::init();

    ServerStategy ss;
    ss.type = DAEMONSERVER;
    ss.threadStategy = MULTITHREAD;
    ss.groupId          = 337;
    ss.port             = 33333;
    ss.name             = "daemon_time_d";
    ss.thread_num       = 16;
    ss.queue_pack_size  = 100000;

    IServerFacade *sf = initEviroment(ss);

    // 初始化libs2sd, 使用s2sName和s2sKey
    s2sd::init("s2sd_time_d", "22494cac3376b418be70f6548fd9d372", s2sd::S2SD_MULTITHREAD_LIB3);
    s2sd::getClient()->addNotifySuffix("s2sd_demo_d");

    // 业务自己的初始化
    DemoContainer app;
    app.init();
    app.setServerFacade(sf);

    SimpleWriter * pWriter = dynamic_cast<MfcAppcontextEx2*>(sf->getAppContext())->getWriter();
    // 让s2sd保有旧daemon指针
    app.setDaemonPointer(pWriter, sf->createGroupNameDispatcherMT());

    // 把业务自己的uri handler添加到s2sd
    // 一定来说是daemon框架定义了"DECLARE_FORM_MAP"的, 都应该添加进来
    s2sd::addUriEntries(&app);  // 注意lib3一定要先于 sf->getAppContext()->addEntry

    // 旧daemon部分
    app.setServer(sf->getDaemonServer());
    // 旧daemon添加uri handler
    RouteRequestProcessor route_requestprocessor;
    route_requestprocessor.SetAppContex(sf->getAppContext());
    sf->getAppContext()->addEntry(RouteRequestProcessor::getFormEntries(), &route_requestprocessor);
    sf->getAppContext()->addEntry(DemoContainer::getFormEntries(), &app);

    // 旧daemon start
    sf->startAllServer();;
    // s2sd start
    s2sd::start();
    // daemon框架的epoll loop
    WrapServerStart::run();
    return 0;
}