
#include "DemoContainer.h"

#include "core/sox/snox.h"
#include "server_common/helper/main_inc.h"
#include "server_common/server-lib/ServerSelectorImp.h"

using namespace core;
using namespace sox;

int main(int sz, char *args[])
{
    init_daemon dm(sz, args);
    WrapServerStart::init();

    CONFIG_RDAEMON_SERVER_INIT("daemon_demo_d",
            BRouteAppContext, 
            MultiConnManagerImp,
            InnerConnCreator,
            InnerConnCreator, 
            BackLinkHandler, 
            RouteWriter,
            TinyXmlServerConfigImp);

    // 业务自己的初始化
    DemoContainer app;
    app.init();

    server::CServerSelectorImp ServerSelectorImp;
    ServerSelectorImp.RegisterServerSuffix(TIME_SERVICE, server::ENUM_HASH_SERVERID, ::ENUM_FUNC_MD5);
    ServerSelectorImp.setDaemonClient(&__clientDaemon);
    app.SetServerSelector(&ServerSelectorImp);

    // 旧daemon部分
    app.setServer(&__server);
    // 旧daemon添加uri handler
    __appContext.addEntry(DemoContainer::getFormEntries(), &app, &app);

    DAEMON_SERVER_START;
    // daemon框架的epoll loop
    WrapServerStart::run();
    return 0;
}