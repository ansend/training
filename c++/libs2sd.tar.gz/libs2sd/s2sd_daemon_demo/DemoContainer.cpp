#include "DemoContainer.h"

using namespace core;

#define FUNLOG(level, fmt, ...)  \
    log(level, "[Demo::%s::%d::%s]: " fmt, __FILE__, __LINE__, __FUNCTION__, ##__VA_ARGS__)

BEGIN_FORM_MAP(DemoContainer)
    ON_LINK(PPing, &DemoContainer::OnPing)
    ON_LINK(PPong, &DemoContainer::OnPong)
    ON_LINK(PTimeRes, &DemoContainer::OnTimeRes)
    ON_LINK(PStrReq, &DemoContainer::OnStrReq)
END_FORM_MAP()

DemoContainer::DemoContainer()
{
}
DemoContainer::~DemoContainer()
{
}
bool DemoContainer::init()
{
    m_timer.init(this);
    m_timer.start(20 * 1000);

    return true;
}

void DemoContainer::OnPing(PPing * pReq, core::IConn* conn)
{
    uint32_t myId = server->getServerId();
    if (myId != pReq->serverId)
    {
        FUNLOG(Warn, "ping server:%llx not mine:%llx", pReq->serverId, myId);
        return ;
    }
    PPong pong;
    pong.serverId = myId;

    answer(pong.uri, RES_SUCCESS, pong);
    FUNLOG(Info, "recv ping from:%s:%u", sox::addr_ntoa(conn->getPeerIp()).c_str(), conn->getPeerPort());
}
void DemoContainer::OnPong(PPong * pRes, core::IConn* conn)
{
    FUNLOG(Info, "recv pong from:%s:%u", sox::addr_ntoa(conn->getPeerIp()).c_str(), conn->getPeerPort());
}

void DemoContainer::OnTimeRes(PTimeRes * pRes, core::IConn* conn)
{
    FUNLOG(Info, "recv time-res from:%s:%u -> id:%llx-%llu",
        sox::addr_ntoa(conn->getPeerIp()).c_str(), conn->getPeerPort(), pRes->serverId, pRes->serverTs);
}
void DemoContainer::OnStrReq(PStrReq * pReq, core::IConn* conn)
{
    PStrRes res;
    res.strReq = pReq->strReq;
    res.strRes = "old-daemon";
    answer(res.uri, RES_SUCCESS, res);
    FUNLOG(Info, "recv strReq:%s", pReq->strReq.c_str());
}

bool DemoContainer::Timer()
{    
    {
        PPing ping;
        ping.serverId = server->getServerId();
        route(TIME_SERVICE, ping.uri, ping);
        FUNLOG(Info, "send ping to server:%s", TIME_SERVICE);
    }

    uint32_t uServerId = GetServerSelector()->RandomServer(TIME_SERVICE);
    if ((uint32_t)-1 != uServerId)
    {
        PTimeReq req;
        routeS(uServerId, req.uri, req);
        FUNLOG(Info, "send time-req to server:%u", uServerId);
    }

    writer->flush();
    return true;
}